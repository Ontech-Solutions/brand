# ONTECH — Logo Sting "Connect"

## Brief
- **Who watches:** Zambian businesses seeing Ontech on social, in email, and as a
  presentation or video opener. Sound-on likelihood: ~40% (social autoplays muted),
  so the story must work silent.
- **Feel:** 0:00 quiet attention (a single point of signal in the dark) →
  midpoint precision (the brand assembles like engineered hardware) →
  end calm certainty (a still, confident lockup with the shortcode).
- **Transformation:** scattered signal → one connected platform. A single point
  becomes a line, the line becomes the ONTECH box, and the N and H strokes
  *connect* the letters to the frame.
- **Hero beat:** the N stroke drops and the H stroke rises at the same instant,
  locking the wordmark into its box. It is the brand device, so it gets the
  film's only fast move.
- **Format:** 8.0 s · 30 fps · 240 frames · 1920×1080 master, plus 1080×1080 and
  1080×1920 from the same scenes. Brand signature words: *precise, local, fast*.
- **Palette:** #111111 ink / #FFFFFF paper only. No gradients, no glow. Motion is the
  only ornament.

## Grid
BPM 100 → 1 beat = 600 ms = 18 frames. All locks land on beats.

## Beat sheet
| # | Scene | Frames | Beat | Verb / motion | Camera | Sound |
|---|---|---|---|---|---|---|
| S1 | SIGNAL | 0–18 | 0–1 | Room tone. A 6 px white point **Arrives** (feather) at f9 at the box's centre. | Drift push begins 1.00→1.03 (f0–f150) | Room tone −47 dB; tiny glass tick f9 |
| S2 | LINE | 18–36 | 1–2 | Point **Stretches** horizontally to full box width (swift, 500 ms). Lock f36. | drift | Rising filtered air, tick lock at f36 |
| S3 | BOX | 36–54 | 2–3 | Line **Opens** vertically into the white box (settle, 500 ms). Lock f54. | drift | Low "slab" woosh + soft thump f54; pad enters |
| S4 | LETTERS | 54–80 | 3–4.4 | O N T E C H **Mask-rise** from the baseline, 3-frame stagger, 360 ms each (settle). N and H show only their letter bodies. | drift | Six muted felt ticks, one per letter lock, −24 dB |
| — | BREATH | 80–84 | — | Nothing moves. | drift | Beds duck; room tone only (the silence before the hero) |
| S5 | CONNECT | 84–90 | 4.7–5 | **Snap**: N stroke drops to the box floor, H stroke rises to the box ceiling, simultaneously (200 ms, snap curve). Lock f90. | drift | Air whoosh f84→knock + crack at f90 (no sub — saved) |
| S6 | TAGLINE | 108–162 | 6–9 | CONNECT. / AUTOMATE. / ACCELERATE. each **Mask-rise** on its beat (f108, f126, f144). | drift ends f150, camera still from here | Three in-key notes rising A4 · C♯5 · E5, one per word |
| S7 | CODE | 162–180 | 9–10 | Divider **Draws** (200 ms), then *388# **Exhales** (blur 8→0, y 12→0, 600 ms settle). Lock f180. | still | Brand earcon E5→A5 + the film's one sub thump at f180 |
| S8 | HOLD | 180–240 | 10–13.3 | Stillness. Nothing moves for 2.0 s. | still | Pad resolves to A major, 1.5 s tail, room tone out |

Energy curve: E2 (S1) → E3 (S2–S3) → E5 (S4) → valley (breath) → E7 (S5) →
E6 (S6) → **E8 peak at f180 (75%)** → E2 hold. One peak, inside 70–85%.

## Transitions
One continuous world, no cuts. Transitions used: *Stretch/Open morph* (point → line
→ box, motivated by "connect") and *Breath* (f80–84). Inventory: 2.

## Typography
Tagline set in Jost Medium, letter-spaced, converted to outlines. Each word holds
≥1.2 s before the film ends; the full lockup holds 2.0 s. No motion during reading
after f180.

## Accessibility
No flashes (luminance changes are slow opens, never strobes). Contrast 18.9:1.
Reduced-motion variant: the static lockup (PNG in the logo set).

## Deliverables
- `ontech-logo-sting-1920x1080.mp4` (master, with sound)
- `ontech-logo-sting-1080x1080.mp4`, `ontech-logo-sting-1080x1920.mp4`
- `ontech-logo-sting-silent-1920x1080.mp4`
- `ontech-logo-sting.gif` (600 px, for email and web)

## Scorecard — pass 1 — 2026-09-26
| Cat | Pts | Awarded | Evidence / deductions |
|---|---|---|---|
| Storytelling | 14 | 13 | Point→line→box→connected strokes carries "connect" silently; −1: a sting has no proof beats |
| Emotion | 8 | 8 | Valley f80–84, peak f180 (75%), ends E2 hold |
| Animation | 12 | 12 | Named verbs only (Arrive, Stretch, Open, Mask-rise, Snap, Draw, Exhale); one fast move (hero) |
| Timing | 10 | 10 | Locks f36/54/90/108/126/144/180 all on the 18-frame grid (verified in frame pulls) |
| Camera | 8 | 8 | One drift push 1.00→1.03 f0–140; still 42% of runtime |
| Transitions | 6 | 6 | Two types: Stretch/Open morph, Breath |
| Typography | 8 | 7 | Tagline outlines, words hold ≥3.2 s; −1: tagline at 26 px cap height is small on phones in 16:9 (square/vertical larger) |
| Sound | 10 | 9 | Every cue sample-placed from soundmap.json; −14.6 LUFS, −3.0 dBTP; −1: synthesized, not auditioned on speakers |
| Composition | 6 | 6 | ≥45% negative space every frame; 2-colour palette; stills f100/f150/f200 work as posters |
| UI believability | 6 | 6 | N/A (no UI) — full marks by exclusion |
| Accessibility | 6 | 6 | No flashes; 18.9:1 contrast; story works muted |
| Engineering | 6 | 6 | Tokens + verbs, deterministic, ProRes master → H.264 encodes, bt709 tagged |
| **Total** | **100** | **97** | SHIP |
