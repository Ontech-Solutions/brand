ONTECH LOGO SET
Connect. Automate. Accelerate.  |  *388#
=====================================================

FOLDERS
  SVG/     Vector masters. Use these for print, signage, web and anything that
           needs to scale. Text is converted to outlines (no fonts needed).
  PNG/     Every logo at 600, 1200 and 2400 px wide, transparent background
           (the "boxed" versions carry their own black frame).
  Icons/   favicon.ico, favicon 16/32/48, apple-touch-icon-180,
           android-chrome 192/512, app/icon 1024 (+ inverse).
  Social/  Profile pictures (1080x1080), LinkedIn banner, X header,
           Facebook cover, WhatsApp status.
  Email/   Email logo (520 px, display at 260 px), email header, signature logo.

WHICH LOGO TO USE
  ontech-primary-*        Main logo: wordmark + tagline + *388#. Default choice.
  ontech-tagline-*        Wordmark + tagline, no shortcode (non-USSD contexts).
  ontech-wordmark-*       Wordmark only, for small spaces or when the tagline
                          is already nearby.
  ontech-boxed*           The original ONTECH device: white box in a black frame.
                          Note how the N and H strokes run to the box edge.
  ontech-box-white        White box without the frame, for dark backgrounds.
  ontech-icon / -inverse  The N device. App icons, favicons, social avatars.

  -black = for light backgrounds    -white = for dark backgrounds

COLOURS
  Ink / Black   #111111   RGB 17 17 17    CMYK 0 0 0 95
  White         #FFFFFF

TYPE
  Wordmark      Custom (from the original ONTECH logo)
  Tagline       Jost Medium, uppercase, wide letter-spacing
  Shortcode     Jost SemiBold
  Jost is free: https://fonts.google.com/specimen/Jost

CLEAR SPACE & MINIMUM SIZE
  Keep clear space around the logo at least the height of the letter "O".
  Primary logo minimum width: 160 px on screen / 35 mm in print
  (below that, use the wordmark or the icon).
  Wordmark minimum width: 80 px / 20 mm.

DON'T
  Stretch, rotate, recolour, add effects or shadows, or shorten the N and H strokes.

NOTE
  The vectors were traced from the supplied logo image. If you have the original
  artwork (AI/EPS/SVG), swap it in for print-critical work.
