# ONTECH brand system — Phase 1 (Foundation)

Generated 2026-09-27. Everything here is produced by the three scripts in `tools/`;
edit the numbers there and rerun rather than editing outputs by hand.

    pip install fonttools brotli cairosvg pillow
    python tools/gen_logo.py     # logo/svg, logo/png, logo/construction.json
    python tools/gen_tokens.py   # tokens/tokens.json, tokens.css, contrast-report.md
    python tools/gen_hub.py      # hub/index.html

The scripts expect Jost (500, 600) and JetBrains Mono SemiBold TTFs in `../fonts/`;
both are OFL. `npm pack @fontsource/jost` and the JetBrains Mono GitHub release
supply them.

## What changed from the 2026-09-26 logo set

- The wordmark, boxed device and icon are rebuilt from geometry (circles and
  rectangles), not traced. Every ratio is in `logo/construction.json`.
- File names say where the logo goes (`-on-light`, `-on-dark`) instead of what
  colour it is.
- The boxed device is the master logo; the plain wordmark is secondary.
- One signal colour (`#F5A524`), a warm neutral scale, semantic colours for
  product UI, and a chart order. 33 contrast pairs checked, none fail.
- A type scale: Jost for display and UI, JetBrains Mono for anything dialled,
  paid or copied.
- A voice guide with the site's headlines rewritten.
- `*388#` gets a standalone mono lockup (pending confirmation of what it is).
- A favicon-specific SVG with a heavier frame so the N reads at 16 px.

## Assumptions to confirm at the Phase 1 gate

See `hub/index.html` → Files → Assumptions, or the Brand Uplift doc.

## Layout

    logo/svg/            16 SVG masters (outlines, no fonts needed)
    logo/png/            600 / 1200 / 2400 px of each lockup
    logo/icons/          favicon.ico, favicon.svg, PNG icons, site.webmanifest
    logo/construction.json
    tokens/tokens.json   colour, type, space, radius, motion
    tokens/tokens.css    CSS custom properties, light + dark
    tokens/contrast-report.md
    guidelines/voice.md
    hub/index.html       the brand hub, self-contained
    tools/               generators

## Phase 2 (Templates) — added 2026-09-27

    templates/deck/ONTECH-deck-template.pptx   12 layouts, speaker notes explain each
    templates/docs/ONTECH-proposal.docx        cover + 3 pages, Word styles mapped to the type scale
    templates/docs/ONTECH-letterhead.docx
    templates/docs/ONTECH-invoice.docx
    templates/email/signature.html             table-based, inline styles, logo embedded
    templates/social/                          6 post templates, WhatsApp status, LinkedIn/X/Facebook banners, profile icon (SVG + PNG)

Generators: `node tools/gen_deck.js`, `node tools/gen_docs.js` (pptxgenjs and docx from npm),
`python tools/gen_social.py`. The deck and documents name Jost and JetBrains Mono; install both
(free, OFL) on any machine that edits them, or PowerPoint and Word will substitute.
Example content (Kwacha Microfinance, K120,000, Dennis Zitha's contact line) is placeholder and must be replaced.

## Phase 3 (Product) — added 2026-09-27

    site/index.html            homepage restyled on the tokens, rewritten copy, *388# demo, contact form
    ui-kit/ontech-ui.css       framework-agnostic components (load tokens/tokens.css first)
    ui-kit/tailwind.preset.js  same tokens as Tailwind utilities
    ui-kit/index.html          working Collections screen + every component, light/dark toggle
    guidelines/ussd.md         *388# menu tree, error screens, SMS receipts; tools/ussd_check.py enforces 160 chars
    motion/                    ontech-sting-4s (16:9, 1:1, 9:16) cut from the 8 s master; ontech-snap-loop.gif

Generators: `python tools/gen_site.py`, `python tools/gen_uikit.py`. The site's contact form is front-end only;
wire the submit handler to your backend. The CRM stack was unknown when this was built, which is why the kit
is plain CSS; once it is known, wrap the classes in that stack's components rather than restyling.
