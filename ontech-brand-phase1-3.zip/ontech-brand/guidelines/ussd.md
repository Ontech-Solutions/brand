# *388# menu copy

Version 1.0 · 2026-09-27 · For the USSD gateway team

## Rules

1. Every screen fits in 160 characters including line breaks. Count them; the gateway truncates silently.
2. First line is who you are talking to: `ONTECH *388#` on the root, the customer's name on their menus (`Kwacha MFI`).
3. Numbered options, one action per line, `0. Back` last on every screen except the root, `00. Home` on any screen deeper than two.
4. Verbs first: `Pay loan`, not `Loan payment`. Match the words in ONTECH CRM exactly so an agent can guide a caller.
5. Amounts as `K 1,200.00`, dates as `30 Sep`, references as `TXN-0093-4471`. Never round an amount the customer will pay.
6. Confirmation screens repeat the amount and what it is for, then ask for the PIN. Never ask for a PIN on the same screen as a choice.
7. Errors say what happened and what to do. Never `Error 42` or `Transaction failed`.
8. Session timeouts (the network drops after ~180 s) restart at the last safe screen, not the root.
9. Bemba and Nyanja versions are written by a native speaker from this file, not machine-translated. Keep numerals and references identical across languages.
10. No marketing on USSD. The customer is paying for airtime; get them through.

## Tree (English)

### 0 · Root (aggregator)

```
ONTECH *388#
1. Kwacha MFI
2. Copperbelt MFI
3. Lusaka Water
4. Language / Icilankulo / Chilankhulo
```
(Root lists the customer's organisations the caller's number is registered with. One organisation → skip to its menu.)

### 1 · Organisation menu

```
Kwacha MFI
Mercy Banda
1. Check balance
2. Pay loan
3. Statement by SMS
4. Talk to us
0. Back
```

### 1.1 · Balance

```
Kwacha MFI
Loan LN-04471
Balance K 3,600.00
Next due K 1,200.00 on 30 Sep
1. Pay now
0. Back
```

### 1.2 · Pay loan (amount)

```
Pay loan LN-04471
1. Pay K 1,200.00 (this month)
2. Pay full K 3,600.00
3. Other amount
0. Back
```

### 1.2.3 · Other amount

```
Enter amount in Kwacha
(minimum K 50)
0. Back
```

### 1.2.x · Confirm

```
Pay K 1,200.00 to Kwacha MFI
for loan LN-04471
from MTN Money 097***456
1. Confirm
0. Back
```

### 1.2.x.1 · PIN (handled by the mobile money operator)

The operator shows its own PIN prompt. We never collect a PIN.

### 1.2.x.1 · Success (end screen)

```
Paid. K 1,200.00 posted to
LN-04471. Ref TXN-0093-4471.
Receipt sent by SMS.
New balance K 2,400.00
```

### 1.3 · Statement

```
Send last 6 payments by SMS to
097***456?
1. Yes
0. Back
```

### 1.4 · Talk to us

```
Kwacha MFI, Kitwe branch
Call 0212 000 000
07:00 to 17:00 Mon to Fri
1. Call me back today
0. Back
```

## Error screens

| Situation | Screen |
| --- | --- |
| Number not registered | `This number is not registered with any ONTECH service. Ask your branch to add 097***456, or call 0211 000 000.` |
| Insufficient balance | `Payment not sent. Your MTN Money balance is below K 1,200.00. Top up and dial *388# again. 0. Back` |
| Operator timeout | `Payment not confirmed. MTN did not answer in time. Nothing was taken. 1. Try again 0. Back` |
| Amount below minimum | `Minimum payment is K 50. Enter a higher amount. 0. Back` |
| Loan already settled | `Loan LN-04471 is fully paid. Nothing is due. Your branch can confirm on 0212 000 000.` |
| System down | `*388# is being repaired. Payments will work again by 14:00. Your due date is not affected.` |

## SMS receipts

Under 160 characters, one SMS, sender ID `ONTECH` (or the customer's registered sender ID).

```
Kwacha MFI: K 1,200.00 received for loan LN-04471 on 27 Sep 14:32. Ref TXN-0093-4471. New balance K 2,400.00. Queries 0212 000 000.
```

Reminder, two days before due:

```
Kwacha MFI: K 1,200.00 for loan LN-04471 is due 30 Sep. Dial *388# to pay from your phone. Queries 0212 000 000.
```

## Character counts

Every screen above is under 160 characters; the longest screen is 99 (SMS receipt 131). Run `tools/ussd_check.py` before shipping changes; it fails on any screen over 160.
