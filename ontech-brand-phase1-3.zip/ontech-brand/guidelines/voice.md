# ONTECH voice

Version 1.0 · 2026-09-27 · Draft for sign-off

## What we sound like

ONTECH builds business systems for Zambian banks, insurers, microfinance lenders, government and schools. The logo is precise and engineered; the writing must match it. Three words, in order of priority: **precise, local, fast.**

- **Precise.** Say the number, the place, the date. "Collections up 31% in Kitwe" beats "improved recovery outcomes".
- **Local.** Write for someone in Lusaka reading on a phone with patchy data. Name Zambian towns, kwacha, *388#, ZRA, MTN and Airtel Money when they are the point. No "emerging markets" framing.
- **Fast.** Short sentences. Lead with what the reader gets. Cut the run-up.

## Rules

1. Lead with the outcome, then how. "Your agents collect from any phone. No app, no data bundle." Not "Our USSD-based platform enables…"
2. Verbs over nouns. "We connect", "you automate", "it accelerates". The tagline is three verbs; the copy should be too.
3. One idea per sentence. Under 20 words. Paragraphs of three sentences or fewer.
4. Numbers as figures, always: 31%, K2.4m, 12 branches, 3 seconds.
5. Plain words. "Use", not "utilise" or "leverage". "Help", not "empower". "Start", not "embark".
6. No metaphors that are not literally true. A contact centre is not a "symphony", a firewall is not a "sentinel". If the thing is impressive, describe what it does.
7. Say who it is for. "For MFIs with 5 to 50 loan officers." Vague inclusivity ("businesses of all sizes") tells nobody it is for them.
8. Product names: **ONTECH** + plain descriptor in Jost, never a second logo. ONTECH CRM, ONTECH Contact Centre, ONTECH Cloud. The shortcode is written ***388#** everywhere, including mid-sentence.
9. Capitalisation: ONTECH in caps in body copy and headings; Ontech only in legal name ("Ontech Solutions Ltd") and URLs.
10. We, you, never "the client" or "the customer" in copy addressed to them.

## Words we stop using

| Stop | Use instead |
| --- | --- |
| signature of excellence | (delete; show the result) |
| end-to-end technology enabler | business systems |
| digital transformation | say what changes: "move collections off paper" |
| leverage, utilise, empower | use, help |
| solutions (as a noun on its own) | the product's name, or "systems" |
| symphony, sentinel, seamless, robust, cutting-edge | (delete) |
| local expertise, global standards | name the standard: "PCI-DSS hosted in Lusaka" |

## Positioning line (draft, to test)

**Business systems that run on any phone in Zambia.**

Under the tagline on the website and the first line of every proposal. It is a claim, so it needs *388# and the CRM to back it. Test with five customers before it goes public. Fallback if the claim is too narrow: "Business systems built in Zambia, for Zambia."

## Rewritten site copy

Current headline → proposed.

| Where | Now | Proposed |
| --- | --- | --- |
| Home hero | We leave a signature of Excellence on every Client | Business systems that run on any phone in Zambia. |
| Home sub | end-to-end technology enabler specializing in digital transformation… | ERP, CRM and USSD services for banks, insurers, MFIs and government. Built and supported from Lusaka. |
| Software | ERP, CRM, Financial Management Systems, custom platforms | Run your operation on one system. ERP, CRM and finance, built for how Zambian companies actually work. |
| Communications | a symphony of customizable voice technologies | Reach every customer, on any phone. USSD, SMS, voice and a contact centre, from one provider. Dial *388# to see it work. |
| Security and continuity | digital sentinel… | Keep running when things go wrong. Risk management, backups and disaster recovery, tested with you every quarter. |
| IT infrastructure | Server migration, maintenance, cloud storage, colocation | Your servers, our racks in Lusaka. Migration, hosting and maintenance without the international latency. |
| BPO | Contact centers, back-office support, marketing campaigns | Hand us the back office. Contact centre, data capture and campaigns, staffed in Zambia. |
| Equipment rental | Computing devices, network equipment, office machines | Kit for the project, not forever. Laptops, network gear and office machines by the month. |
| Site footer / CTA | Contact us | Talk to an engineer, not a sales line. +260 … / Dial *388# |

## Tone by surface

| Surface | Register | Example |
| --- | --- | --- |
| USSD menu | Terse, numbered, one action per line, max 160 chars per screen | "ONTECH *388#  1. Check balance  2. Pay loan  3. Talk to us" |
| Proposal | Plain, specific, outcome first, numbers in tables | "Go-live in 6 weeks. K120,000 fixed." |
| Social post | One sentence, one number, one link | "12 MFIs now collect through *388#. Here is what changed for one of them." |
| Support reply | Direct, apologise once, state the fix and the time | "The SMS gateway was down 09:10 to 09:42. Queued messages have been sent. We have added a second route." |
| Error message in product | What happened, what to do | "Payment not sent. Check the phone number and try again." |
