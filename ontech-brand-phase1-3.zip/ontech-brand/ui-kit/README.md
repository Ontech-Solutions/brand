# ONTECH UI kit

Framework-agnostic. Two stylesheets, in this order:

    <link rel="stylesheet" href="tokens/tokens.css">
    <link rel="stylesheet" href="ui-kit/ontech-ui.css">

Wrap the app in `.on-app`. Classes are prefixed `on-`; see `index.html` for every component in a
working Collections screen, in light and dark (toggle top right, or follow the system).

Tailwind users: `presets: [require('./ui-kit/tailwind.preset.js')]` gives the same colours,
type scale, spacing and radii as utilities (`bg-signal`, `text-success-text`, `font-mono`, `text-h1`).

React / Blazor / PHP: use the classes directly, or wrap them in components. The kit has no JavaScript
except the theme toggle on the demo page. Modals use the native `<dialog>` element with `.on-modal`.

Rules that matter in product UI:

1. One primary button per view. It is amber with an ink border on light, amber without a border on dark.
2. Status is a pill with a dot, never colour on the text alone. Success, warning, error, info, neutral, live.
3. Anything a person dials, pays or copies is in the mono face with tabular figures: loan numbers, amounts, references, phone numbers.
4. Error messages say what happened and what to do: "Payment not sent. Check the phone number and try again."
5. Dark mode comes from the tokens; do not hard-code colours in components.
