// ONTECH Tailwind preset — generated from tokens/tokens.json
module.exports = {
  "theme": {
    "extend": {
      "colors": {
        "ink": "#111111",
        "paper": "#FFFFFF",
        "neutral": {
          "900": "#1F1D1A",
          "800": "#33302B",
          "700": "#55504A",
          "600": "#6E6861",
          "500": "#8E8780",
          "400": "#B3ACA4",
          "300": "#D6D0C8",
          "200": "#E9E5DF",
          "100": "#F4F1EC"
        },
        "signal": {
          "DEFAULT": "#F5A524",
          "strong": "#945600",
          "soft": "#FFF1D6",
          "dark": "#FFB84D"
        },
        "success": {
          "text": "#1E7B3E",
          "DEFAULT": "#2FA35A",
          "soft": "#E3F4E8",
          "dark": "#6FD48F",
          "darksoft": "#153A22"
        },
        "warning": {
          "text": "#9A5B00",
          "DEFAULT": "#CC7A00",
          "soft": "#FFF0D6",
          "dark": "#FFC266",
          "darksoft": "#3E2A08"
        },
        "error": {
          "text": "#B3261E",
          "DEFAULT": "#D93A31",
          "soft": "#FBE5E3",
          "dark": "#FF8A80",
          "darksoft": "#4A1512"
        },
        "info": {
          "text": "#1F5FA8",
          "DEFAULT": "#2F7BD1",
          "soft": "#E4EEFA",
          "dark": "#8CBDF2",
          "darksoft": "#12294A"
        },
        "chart": {
          "1": "#F5A524",
          "2": "#2F7BD1",
          "3": "#2FA35A",
          "4": "#8E8780",
          "5": "#D93A31",
          "6": "#7A5AC9",
          "7": "#1F9FA8",
          "8": "#C67A00"
        }
      },
      "fontFamily": {
        "sans": [
          "Jost",
          "system-ui",
          "sans-serif"
        ],
        "mono": [
          "JetBrains Mono",
          "ui-monospace",
          "monospace"
        ]
      },
      "fontSize": {
        "display": [
          "3.5rem",
          {
            "lineHeight": "1.05",
            "letterSpacing": "-0.02em",
            "fontWeight": "600"
          }
        ],
        "h1": [
          "2.5rem",
          {
            "lineHeight": "1.1",
            "letterSpacing": "-0.015em",
            "fontWeight": "600"
          }
        ],
        "h2": [
          "1.75rem",
          {
            "lineHeight": "1.2",
            "letterSpacing": "-0.01em",
            "fontWeight": "600"
          }
        ],
        "h3": [
          "1.25rem",
          {
            "lineHeight": "1.3",
            "letterSpacing": "0",
            "fontWeight": "500"
          }
        ],
        "body": [
          "1rem",
          {
            "lineHeight": "1.55",
            "letterSpacing": "0",
            "fontWeight": "400"
          }
        ],
        "small": [
          "0.875rem",
          {
            "lineHeight": "1.5",
            "letterSpacing": "0",
            "fontWeight": "400"
          }
        ],
        "label": [
          "0.75rem",
          {
            "lineHeight": "1.3",
            "letterSpacing": "0.14em",
            "fontWeight": "500"
          }
        ],
        "code": [
          "0.875rem",
          {
            "lineHeight": "1.5",
            "letterSpacing": "0",
            "fontWeight": "500"
          }
        ]
      },
      "spacing": {
        "1": "4px",
        "2": "8px",
        "3": "12px",
        "4": "16px",
        "5": "24px",
        "6": "32px",
        "7": "48px",
        "8": "64px",
        "9": "96px"
      },
      "borderRadius": {
        "none": "0px",
        "sm": "4px",
        "md": "8px",
        "lg": "12px",
        "pill": "999px"
      },
      "transitionDuration": {
        "instant": "120ms",
        "quick": "200ms",
        "standard": "300ms",
        "deliberate": "500ms"
      }
    }
  }
};
