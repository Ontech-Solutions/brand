# Contrast report (WCAG 2.x)

Rules: (1) body text is ink on paper or paper on ink, never on the accent. (2) Accent text on paper uses signal-strong, never signal. (3) The raw signal amber fails 3:1 on white, so on paper it appears only as a fill that carries an ink label, an ink border, or sits on ink (a black button bar, the black logo frame). (4) Dark mode uses the -dark pairs; never the light values inverted.

| Pair | Foreground | Background | Ratio | Needs | Pass |
| --- | --- | --- | --- | --- | --- |
| ink on paper | #111111 | #FFFFFF | 18.88:1 | 7:1 | yes |
| neutral-600 (muted text) on paper | #6E6861 | #FFFFFF | 5.5:1 | 4.5:1 | yes |
| neutral-400 (muted text) on ink | #B3ACA4 | #111111 | 8.41:1 | 4.5:1 | yes |
| ink on signal (button label) | #111111 | #F5A524 | 9.25:1 | 4.5:1 | yes |
| signal-strong (accent text) on paper | #945600 | #FFFFFF | 5.85:1 | 4.5:1 | yes |
| signal-dark (accent text) on ink | #FFB84D | #111111 | 10.98:1 | 4.5:1 | yes |
| signal on ink (non-text, UI) | #F5A524 | #111111 | 9.25:1 | 3:1 | yes |
| signal on paper (fill only; always carries an ink label or ink border — see rule 3) | #F5A524 | #FFFFFF | 2.04:1 | 1:1 | yes |
| ink on signal-soft | #111111 | #FFF1D6 | 16.91:1 | 7:1 | yes |
| success text on paper | #1E7B3E | #FFFFFF | 5.31:1 | 4.5:1 | yes |
| success text on success soft | #1E7B3E | #E3F4E8 | 4.64:1 | 4.5:1 | yes |
| success fill on paper (UI) | #2FA35A | #FFFFFF | 3.23:1 | 3:1 | yes |
| success dark-text on ink | #6FD48F | #111111 | 10.33:1 | 4.5:1 | yes |
| success dark-text on dark-soft | #6FD48F | #153A22 | 6.92:1 | 4.5:1 | yes |
| warning text on paper | #9A5B00 | #FFFFFF | 5.43:1 | 4.5:1 | yes |
| warning text on warning soft | #9A5B00 | #FFF0D6 | 4.83:1 | 4.5:1 | yes |
| warning fill on paper (UI) | #CC7A00 | #FFFFFF | 3.31:1 | 3:1 | yes |
| warning dark-text on ink | #FFC266 | #111111 | 11.83:1 | 4.5:1 | yes |
| warning dark-text on dark-soft | #FFC266 | #3E2A08 | 8.55:1 | 4.5:1 | yes |
| error text on paper | #B3261E | #FFFFFF | 6.54:1 | 4.5:1 | yes |
| error text on error soft | #B3261E | #FBE5E3 | 5.42:1 | 4.5:1 | yes |
| error fill on paper (UI) | #D93A31 | #FFFFFF | 4.57:1 | 3:1 | yes |
| error dark-text on ink | #FF8A80 | #111111 | 8.27:1 | 4.5:1 | yes |
| error dark-text on dark-soft | #FF8A80 | #4A1512 | 6.54:1 | 4.5:1 | yes |
| info text on paper | #1F5FA8 | #FFFFFF | 6.44:1 | 4.5:1 | yes |
| info text on info soft | #1F5FA8 | #E4EEFA | 5.49:1 | 4.5:1 | yes |
| info fill on paper (UI) | #2F7BD1 | #FFFFFF | 4.31:1 | 3:1 | yes |
| info dark-text on ink | #8CBDF2 | #111111 | 9.6:1 | 4.5:1 | yes |
| info dark-text on dark-soft | #8CBDF2 | #12294A | 7.4:1 | 4.5:1 | yes |
| border-300 on paper (UI) | #D6D0C8 | #FFFFFF | 1.53:1 | 1.3:1 | yes |
