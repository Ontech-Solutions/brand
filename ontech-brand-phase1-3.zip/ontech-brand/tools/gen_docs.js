// ONTECH Word templates: letterhead, proposal, invoice. A4, Jost, tokens.
const fs = require("fs"), path = require("path");
const D = require("docx");
const { Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType, AlignmentType, HeadingLevel, BorderStyle, ShadingType, Header, Footer, PageNumber, TabStopType, LevelFormat, PositionalTab, PositionalTabAlignment, PositionalTabLeader, PositionalTabRelativeTo } = D;

const ROOT = path.join(__dirname, "out", "ontech-brand");
const png = (n) => fs.readFileSync(path.join(ROOT, "logo", "png", n));
const INK = "111111", N600 = "6E6861", N300 = "D6D0C8", N100 = "F4F1EC", STRONG = "945600", SIGNAL = "F5A524";
const F = "Jost", MONO = "JetBrains Mono";
const PAGE_W = 11906, PAGE_H = 16838, MARG = 1418; // A4, 25 mm
const CONTENT_W = PAGE_W - 2 * MARG;

const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: none, bottom: none, left: none, right: none, insideHorizontal: none, insideVertical: none };
const hair = { style: BorderStyle.SINGLE, size: 4, color: N300 };
const rule = { style: BorderStyle.SINGLE, size: 8, color: INK };

const styles = {
  default: { document: { run: { font: F, size: 21, color: INK }, paragraph: { spacing: { line: 320, lineRule: D.LineRuleType.AUTO, after: 140 } } } },
  paragraphStyles: [
    { id: "Title", name: "Title", basedOn: "Normal", next: "Normal", run: { size: 56, bold: true, font: F }, paragraph: { spacing: { before: 0, after: 200, line: 264, lineRule: D.LineRuleType.AUTO } } },
    { id: "Heading1", name: "heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 36, bold: true, font: F }, paragraph: { spacing: { before: 480, after: 160, line: 264, lineRule: D.LineRuleType.AUTO }, outlineLevel: 0 } },
    { id: "Heading2", name: "heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, font: F }, paragraph: { spacing: { before: 320, after: 100 }, outlineLevel: 1 } },
    { id: "Label", name: "Label", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 16, font: F, color: N600, characterSpacing: 40, allCaps: true }, paragraph: { spacing: { before: 0, after: 60 } } },
    { id: "Muted", name: "Muted", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 19, color: N600 } },
    { id: "Code", name: "Code", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: MONO, size: 19 } },
    { id: "BigNumber", name: "Big Number", basedOn: "Normal", next: "Normal", run: { size: 64, bold: true, font: F }, paragraph: { spacing: { before: 0, after: 60, line: 264, lineRule: D.LineRuleType.AUTO } } },
  ],
};
const numbering = { config: [
  { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 400, hanging: 400 } } } }] },
  { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 400, hanging: 400 } }, run: { font: MONO, color: STRONG } } }] },
] };

const P = (text, o = {}) => new Paragraph(Object.assign({ children: [new TextRun(Object.assign({ text }, o.run || {}))] }, o.para || {}));
const label = (t) => new Paragraph({ style: "Label", children: [new TextRun(t)] });
const muted = (t) => new Paragraph({ style: "Muted", children: [new TextRun(t)] });
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const bullet = (t) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, children: [new TextRun(t)] });
const numbered = (t) => new Paragraph({ numbering: { reference: "numbers", level: 0 }, children: [new TextRun(t)] });
const spacer = (after = 200) => new Paragraph({ spacing: { after }, children: [] });

const logo = (w = 1500) => new Paragraph({ children: [new ImageRun({ type: "png", data: png("ontech-boxed-1200.png"), transformation: { width: w / 10, height: (w / 10) * (191 / 566) } })], spacing: { after: 0, line: 240, lineRule: D.LineRuleType.AUTO } });

function header() {
  return new Header({ children: [new Paragraph({ children: [new ImageRun({ type: "png", data: png("ontech-wordmark-on-light-600.png"), transformation: { width: 78, height: 78 * (146 / 423) } })], spacing: { after: 0 } })] });
}
function footer(left) {
  return new Footer({ children: [new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: CONTENT_W }],
    children: [new TextRun({ text: left, size: 16, color: N600 }), new TextRun({ text: "\t", size: 16 }), new TextRun({ children: [PageNumber.CURRENT], font: MONO, size: 16, color: N600 })],
    border: { top: { style: BorderStyle.SINGLE, size: 4, color: N300, space: 6 } },
  })] });
}
const LEGAL = "Ontech Solutions Ltd  ·  Lusaka, Zambia  ·  ontech.co.zm  ·  *388#";

function signTable() {
  const cell = (w, kids) => new TableCell({ width: { size: w, type: WidthType.DXA }, borders: { top: none, left: none, right: none, bottom: rule }, margins: { top: 100, bottom: 100, left: 0, right: 200 }, children: kids });
  return new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: [4535, 4535], borders: noBorders, rows: [new TableRow({ children: [
    cell(4535, [label("For Kwacha Microfinance"), spacer(900), muted("Name, title, date")]),
    cell(4535, [label("For Ontech Solutions"), spacer(900), muted("Dennis Zitha, date")]),
  ] })] });
}
function kvTable(rows, colA = 2400) {
  return new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: [colA, CONTENT_W - colA], borders: noBorders,
    rows: rows.map(([k, v]) => new TableRow({ children: [
      new TableCell({ width: { size: colA, type: WidthType.DXA }, borders: { bottom: hair }, margins: { top: 100, bottom: 100, left: 0, right: 120 }, children: [new Paragraph({ spacing: { after: 0 }, children: [new TextRun({ text: k, color: N600, size: 19 })] })] }),
      new TableCell({ width: { size: CONTENT_W - colA, type: WidthType.DXA }, borders: { bottom: hair }, margins: { top: 100, bottom: 100, left: 0, right: 0 }, children: [new Paragraph({ spacing: { after: 0 }, children: [new TextRun({ text: v, size: 19 })] })] }),
    ] })) });
}

function dataTable(head, rows, widths, opts = {}) {
  const right = opts.right || [];
  const cell = (t, i, isHead) => new TableCell({ width: { size: widths[i], type: WidthType.DXA },
    borders: { top: none, left: none, right: none, bottom: isHead ? rule : hair },
    margins: { top: 90, bottom: 90, left: 0, right: 120 },
    children: [new Paragraph({ spacing: { after: 0 }, alignment: right.includes(i) ? AlignmentType.RIGHT : AlignmentType.LEFT,
      children: [new TextRun(isHead ? { text: t.toUpperCase(), size: 15, color: N600, characterSpacing: 30 } : { text: t, size: 19, font: right.includes(i) ? MONO : F })] })] });
  return new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: widths, borders: noBorders,
    rows: [new TableRow({ tableHeader: true, children: head.map((h, i) => cell(h, i, true)) }), ...rows.map(r => new TableRow({ children: r.map((c, i) => cell(c, i, false)) }))] });
}

const pageProps = { page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1418, right: MARG, bottom: 1418, left: MARG, header: 600, footer: 600 } } };

// ---------------- Letterhead ----------------
function letterhead() {
  return new Document({ styles, numbering, sections: [{ properties: pageProps, headers: { default: header() }, footers: { default: footer(LEGAL) }, children: [
    spacer(300),
    muted("27 September 2026"),
    spacer(100),
    P("Mrs Chanda Mwila"), P("Chief Executive Officer", { para: { spacing: { after: 0 } } }), P("Kwacha Microfinance Ltd", { para: { spacing: { after: 0 } } }), P("Plot 1234, Cairo Road, Lusaka"),
    spacer(200),
    P("Re: Collections pilot, Kitwe branch", { run: { bold: true } }),
    P("Dear Mrs Mwila,"),
    P("Thank you for Thursday. This letter confirms what we agreed: a six-week pilot of *388# collections at your Kitwe branch, starting Monday 5 October, at the fixed price in the attached proposal."),
    P("Your loan book export reaches us by 1 October. We configure the USSD menu in week 2 and train the 14 Kitwe agents over two half-days in weeks 3 and 4. The first live payments post in week 5. By the end of week 6 the branch closes its month-end in the CRM."),
    P("One thing we need from you before we start: the signed aggregator form for MTN and Airtel, so *388# routes to your book. It is two pages and we have attached it."),
    P("Call me directly on the number below if anything here is not what you expected."),
    spacer(200),
    P("Kind regards,"),
    spacer(400),
    P("Dennis Zitha", { run: { bold: true }, para: { spacing: { after: 0 } } }),
    muted("Ontech Solutions Ltd  ·  +260 97 000 0000  ·  dennis@ontech.co.zm"),
  ] }] });
}

// ---------------- Proposal ----------------
function proposal() {
  const cover = [
    logo(2100), spacer(2400),
    label("Proposal  ·  27 September 2026"),
    new Paragraph({ style: "Title", children: [new TextRun("Collections that reach every borrower, on any phone.")] }),
    muted("Prepared for Kwacha Microfinance Ltd"),
    muted("Valid for 30 days  ·  Ref ON-2026-0142"),
    spacer(3600),
    kvTable([["Prepared by", "Dennis Zitha, Ontech Solutions Ltd"], ["Contact", "+260 97 000 0000  ·  dennis@ontech.co.zm"], ["Confidential", "For Kwacha Microfinance only"]]),
    new Paragraph({ children: [new D.PageBreak()] }),
  ];
  const body = [
    h1("The short version"),
    P("Your 41 agents spend 3 of every 5 working hours travelling to collect cash. We move collections onto *388#, so borrowers pay from any phone and agents visit only the ones who did not. Twelve MFIs have done this with us; the median saw 31% more collected per agent within six months."),
    P("Fixed price K120,000 for a six-week rollout, then K9,500 a month. Go-live by 13 November 2026.", { run: { bold: true } }),
    h1("Where collections stand today"),
    P("From the timesheets and ledger you sent on 19 September:"),
    dataTable(["Measure", "Kitwe", "Ndola", "All branches"], [["Agents", "14", "12", "41"], ["Collected per agent per month", "K41,000", "K38,500", "K39,800"], ["Visits per month", "2,120", "1,780", "6,300"], ["Days to reconcile", "4", "4", "4"]], [3700, 1790, 1790, 1790], { right: [1, 2, 3] }),
    spacer(),
    h1("What changes"),
    h2("For borrowers"),
    P("They dial *388#, choose the loan, and confirm with a PIN. It works on any phone, with no app and no data bundle. They get an SMS receipt within seconds."),
    h2("For agents"),
    P("They see who has paid on the CRM before leaving the office and visit only the 8% who did not. No cash on the road."),
    h2("For the branch"),
    P("Every payment posts to the ledger within 3 seconds. Month-end closes in the CRM, not in a spreadsheet."),
    h1("The system"),
    bullet("ONTECH CRM: loans, borrowers, agents and branches in one place, for up to 50 users."),
    bullet("ONTECH Connect: *388# for payments and balances; SMS reminders two days before due, in English, Bemba or Nyanja."),
    bullet("ONTECH Pay: posting to your core system or ours, reconciled nightly, full export at any time."),
    h1("Rollout"),
    dataTable(["Week", "What happens", "We need from you", "Done when"], [
      ["1", "Kick-off, data import", "Loan book export, 2 staff for a day", "Every borrower in the CRM"],
      ["2", "USSD menu, short code linked", "Signed aggregator form", "*388# answers on a test phone"],
      ["3–4", "Agent training, 2 half-days per branch", "Agents present, a room", "Every agent has logged a test payment"],
      ["5", "Pilot at Kitwe with live borrowers", "Branch manager on call", "100 real payments posted"],
      ["6", "Go-live, all branches", "Sign-off", "First month-end closed in the CRM"],
    ], [900, 3200, 2600, 2370]),
    spacer(),
    h1("Price"),
    new Paragraph({ style: "BigNumber", children: [new TextRun("K120,000")] }),
    muted("Fixed price for the six-week rollout. Includes the CRM for up to 50 users, USSD and SMS set-up, agent training at every branch, and data import. Excludes network fees, which MTN and Airtel bill you directly."),
    spacer(100),
    kvTable([["Then", "K9,500 per month: hosting in Lusaka, support 07:00 to 19:00, updates"], ["Payment", "50% on signing, 50% at go-live"], ["Contract", "12 months, then monthly"], ["Data", "Yours. Full export at any time, no fee"], ["Uptime", "99.5% monthly, service credits if we miss it"], ["Support", "An engineer on the phone, not a ticket queue"]]),
    h1("Next step"),
    numbered("Sign the last page and return it by 1 October."),
    numbered("Send the loan book export the same day."),
    numbered("We kick off on Monday 5 October at Kitwe."),
    spacer(400),
    signTable(),
  ];
  return new Document({ styles, numbering, sections: [
    { properties: pageProps, footers: { default: footer(LEGAL) }, children: cover },
    { properties: pageProps, headers: { default: header() }, footers: { default: footer("Proposal ON-2026-0142  ·  Kwacha Microfinance  ·  Confidential") }, children: body },
  ] });
}

// ---------------- Invoice ----------------
function invoice() {
  const lines = [["ONTECH CRM rollout, 6 weeks, fixed price (50% on signing)", "1", "60,000.00", "60,000.00"], ["USSD short code set-up, MTN and Airtel", "1", "0.00", "0.00"], ["Agent training, Kitwe and Ndola, 4 half-days", "4", "0.00", "0.00"]];
  const totals = [["Subtotal", "60,000.00"], ["VAT 16%", "9,600.00"], ["Total due", "K69,600.00"]];
  const totCell = (t, bold, right) => new TableCell({ width: { size: right ? 2400 : 6670, type: WidthType.DXA }, borders: { top: none, left: none, right: none, bottom: bold ? rule : hair }, margins: { top: 90, bottom: 90, left: 0, right: 120 },
    children: [new Paragraph({ spacing: { after: 0 }, alignment: right ? AlignmentType.RIGHT : AlignmentType.LEFT, children: [new TextRun({ text: t, bold, size: bold ? 24 : 19, font: right ? MONO : F })] })] });
  return new Document({ styles, numbering, sections: [{ properties: pageProps, footers: { default: footer(LEGAL + "  ·  TPIN 1000000000  ·  VAT 1000000000") }, children: [
    logo(1500), spacer(400),
    new Paragraph({ style: "Title", children: [new TextRun("Invoice")] }),
    new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: [4535, 4535], borders: noBorders, rows: [new TableRow({ children: [
      new TableCell({ width: { size: 4535, type: WidthType.DXA }, borders: noBorders, margins: { left: 0, right: 200 }, children: [label("Bill to"), P("Kwacha Microfinance Ltd", { run: { bold: true }, para: { spacing: { after: 0 } } }), P("Plot 1234, Cairo Road, Lusaka", { para: { spacing: { after: 0 } } }), P("TPIN 2000000000", { para: { spacing: { after: 0 } } })] }),
      new TableCell({ width: { size: 4535, type: WidthType.DXA }, borders: noBorders, margins: { left: 0, right: 0 }, children: [kvTable([["Invoice no.", "ON-INV-2026-0311"], ["Date", "27 September 2026"], ["Due", "11 October 2026 (14 days)"], ["Reference", "Proposal ON-2026-0142"]], 1800)] }),
    ] })] }),
    spacer(400),
    dataTable(["Description", "Qty", "Unit (K)", "Amount (K)"], lines, [5470, 900, 1300, 1400], { right: [1, 2, 3] }),
    new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: [6670, 2400], borders: noBorders, rows: totals.map(([k, v], i) => new TableRow({ children: [totCell(k, i === 2, false), totCell(v, i === 2, true)] })) }),
    spacer(400),
    label("Pay by bank transfer"),
    kvTable([["Account name", "Ontech Solutions Ltd"], ["Bank", "Zanaco, Cairo Road branch"], ["Account", "0000000000000"], ["Branch code", "010001"], ["Reference", "ON-INV-2026-0311"]], 2400),
    spacer(200),
    muted("Or pay by mobile money: dial *388#, choose 3, enter the invoice number. A receipt is sent by SMS."),
    spacer(200),
    muted("Terms: 14 days. Late payments accrue 2% per month. Questions: accounts@ontech.co.zm."),
  ] }] });
}

(async () => {
  const dir = path.join(ROOT, "templates", "docs"); fs.mkdirSync(dir, { recursive: true });
  for (const [name, doc] of [["ONTECH-letterhead.docx", letterhead()], ["ONTECH-proposal.docx", proposal()], ["ONTECH-invoice.docx", invoice()]]) {
    fs.writeFileSync(path.join(dir, name), await Packer.toBuffer(doc)); console.log("wrote", name);
  }
})();
