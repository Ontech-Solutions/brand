"""
ONTECH wordmark — geometric construction.
All values are derived from the cap height (CAP). Change CAP and everything scales.
Measured from the traced original: stem = 0.155 CAP, bar = 0.141 CAP, letter gap = 0.10 CAP,
N descender / H ascender = 0.44 CAP, O and C share one circle of diameter = CAP.
"""
import math, os, json
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

CAP = 78.0
S = 12.0          # stem
B = 11.0          # horizontal bar
GAP = 8.0         # letter gap
OVER = 34.0       # N drop below baseline / H rise above cap
R = CAP / 2       # O and C outer radius
RI = R - S        # inner radius
CUT = 15.0        # C aperture half-height (horizontal terminals)

INK = "#111111"
PAPER = "#FFFFFF"
ACCENT = "#F5A524"


def f(v):
    return ("%.2f" % v).rstrip("0").rstrip(".")


def rect(x, y, w, h):
    return f"M{f(x)},{f(y)}h{f(w)}v{f(h)}h{f(-w)}z"


def ring(cx, cy, ro, ri):
    # outer clockwise, inner counter-clockwise -> nonzero fill leaves a hole
    o = (f"M{f(cx-ro)},{f(cy)}a{f(ro)},{f(ro)} 0 1 1 {f(2*ro)},0"
         f"a{f(ro)},{f(ro)} 0 1 1 {f(-2*ro)},0z")
    i = (f"M{f(cx-ri)},{f(cy)}a{f(ri)},{f(ri)} 0 1 0 {f(2*ri)},0"
         f"a{f(ri)},{f(ri)} 0 1 0 {f(-2*ri)},0z")
    return o + i


def c_glyph(cx, cy, ro, ri, cut):
    # ring with a horizontal-terminal aperture on the right
    xo = math.sqrt(ro*ro - cut*cut)
    xi = math.sqrt(ri*ri - cut*cut)
    top_o = (cx + xo, cy - cut); top_i = (cx + xi, cy - cut)
    bot_o = (cx + xo, cy + cut); bot_i = (cx + xi, cy + cut)
    d = (f"M{f(top_o[0])},{f(top_o[1])}"
         f"A{f(ro)},{f(ro)} 0 1 0 {f(bot_o[0])},{f(bot_o[1])}"
         f"L{f(bot_i[0])},{f(bot_i[1])}"
         f"A{f(ri)},{f(ri)} 0 1 1 {f(top_i[0])},{f(top_i[1])}z")
    return d


def wordmark_paths():
    """Returns list of (letter, path d, advance) with cap top at y=0, baseline y=CAP."""
    x = 0.0
    out = []
    # O
    out.append(("O", ring(x + R, R, R, RI), CAP))
    x += CAP + GAP
    # N — width 61: stems S, diagonal S perpendicular
    wN = 61.0
    left = rect(x, 0, S, CAP + OVER)
    right = rect(x + wN - S, 0, S, CAP)
    dtop = 14.0  # horizontal width of the diagonal
    diag = (f"M{f(x)},0h{f(dtop)}L{f(x+wN)},{f(CAP)}h{f(-dtop)}z")
    out.append(("N", left + right + diag, wN))
    x += wN + GAP
    # T — width 59
    wT = 59.0
    out.append(("T", rect(x, 0, wT, B) + rect(x + (wT - S)/2, 0, S, CAP), wT))
    x += wT + GAP
    # E — width 51, middle bar 46
    wE = 51.0
    mid_y = (CAP - B) / 2
    out.append(("E", rect(x, 0, S, CAP) + rect(x, 0, wE, B) + rect(x, mid_y, 46, B)
                + rect(x, CAP - B, wE, B), wE))
    x += wE + GAP
    # C — same circle as O, aperture on right
    xo = math.sqrt(R*R - CUT*CUT)
    wC = R + xo
    out.append(("C", c_glyph(x + R, R, R, RI, CUT), wC))
    x += wC + GAP
    # H — width 59, right stem rises
    wH = 59.0
    out.append(("H", rect(x, 0, S, CAP) + rect(x + wH - S, -OVER, S, CAP + OVER)
                + rect(x, mid_y, wH, B), wH))
    x += wH
    return out, x


def text_path(text, font_path, size, tracking_em=0.0):
    """Outline text with fontTools. Returns (d, width) at cap-top y=0 baseline y=cap."""
    font = TTFont(font_path)
    upm = font["head"].unitsPerEm
    cmap = font.getBestCmap()
    gs = font.getGlyphSet()
    hmtx = font["hmtx"]
    scale = size / upm
    pen = SVGPathPen(gs, ntos=f)
    x = 0.0
    for ch in text:
        gname = cmap.get(ord(ch))
        if gname is None:
            x += 0.3 * size
            continue
        tp = TransformPen(pen, (scale, 0, 0, -scale, x, 0))
        gs[gname].draw(tp)
        x += hmtx[gname][0] * scale + tracking_em * size
    d = pen.getCommands()
    return d, x - tracking_em * size


ROOT = os.path.join(os.path.dirname(__file__), "out", "ontech-brand")
FONT_M = os.path.join(os.path.dirname(__file__), "fonts", "Jost-500.ttf")
FONT_SB = os.path.join(os.path.dirname(__file__), "fonts", "Jost-600.ttf")
FONT_MONO = os.path.join(os.path.dirname(__file__), "fonts", "jbm", "fonts", "ttf", "JetBrainsMono-SemiBold.ttf")


def svg(w, h, body, vb=None, title="ONTECH"):
    vb = vb or f"0 0 {f(w)} {f(h)}"
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" width="{f(w)}" height="{f(h)}">'
            f'<title>{title}</title>{body}</svg>')


def write(name, content):
    os.makedirs(os.path.dirname(name), exist_ok=True)
    with open(name, "w") as fh:
        fh.write(content)


def build():
    letters, W = wordmark_paths()
    H = CAP + 2 * OVER  # -OVER .. CAP+OVER
    wm_d = "".join(d for _, d, _ in letters)
    wm_group = lambda fill, dx=0, dy=0: (
        f'<g transform="translate({f(dx)},{f(dy + OVER)})">'
        f'<path fill="{fill}" fill-rule="nonzero" d="{wm_d}"/></g>')

    svgdir = os.path.join(ROOT, "logo", "svg")

    # 1. wordmark
    for name, fill in [("on-light", INK), ("on-dark", PAPER)]:
        write(os.path.join(svgdir, f"ontech-wordmark-{name}.svg"),
              svg(W, H, wm_group(fill)))

    # tagline + shortcode geometry (Jost Medium caps, tracked; Jost SemiBold shortcode)
    # size the tagline + divider + shortcode so the block spans exactly the wordmark width
    _, tw1 = text_path("CONNECT.  AUTOMATE.  ACCELERATE.", FONT_M, 1.0, tracking_em=0.18)
    _, cw1 = text_path("*388#", FONT_SB, 1.12, tracking_em=0.04)
    div_w = 1.6
    tag_size = (W - (CAP * 0.22) * 2 - div_w) / (tw1 + cw1)
    tag_d, tag_w = text_path("CONNECT.  AUTOMATE.  ACCELERATE.", FONT_M, tag_size, tracking_em=0.18)
    code_d, code_w = text_path("*388#", FONT_SB, tag_size * 1.12, tracking_em=0.04)
    cap_tag = 0.70 * tag_size          # Jost capHeight 700/1000
    cap_code = 0.70 * tag_size * 1.12
    tag_gap = CAP * 0.28               # space between baseline overshoot and tagline
    tag_y = H + tag_gap + cap_tag  # baseline of tagline, below the N descender

    def tagline_block(fill, with_code, total_w):
        # centred under wordmark
        parts = []
        block_w = tag_w + ((CAP * 0.22) * 2 + div_w + code_w if with_code else 0)
        x0 = (total_w - block_w) / 2
        parts.append(f'<path fill="{fill}" transform="translate({f(x0)},{f(tag_y)})" d="{tag_d}"/>')
        if with_code:
            xd = x0 + tag_w + CAP * 0.22
            parts.append(f'<rect fill="{fill}" x="{f(xd)}" y="{f(tag_y - cap_code - 3)}" width="{f(div_w)}" height="{f(cap_code + 6)}"/>')
            xc = xd + div_w + CAP * 0.22
            parts.append(f'<path fill="{fill}" transform="translate({f(xc)},{f(tag_y + 0.5)})" d="{code_d}"/>')
        return "".join(parts)

    H_tag = tag_y + 2
    # 2. tagline lockup, 3. primary lockup
    for name, fill in [("on-light", INK), ("on-dark", PAPER)]:
        write(os.path.join(svgdir, f"ontech-tagline-{name}.svg"),
              svg(W, H_tag, wm_group(fill) + tagline_block(fill, False, W)))
        write(os.path.join(svgdir, f"ontech-primary-{name}.svg"),
              svg(W, H_tag, wm_group(fill) + tagline_block(fill, True, W)))

    # 4. boxed device — master logo. Frame = 22, side padding = 50; N and H run to the frame.
    FR, PAD = 22.0, 50.0
    bw, bh = W + 2 * PAD + 2 * FR, H + 2 * FR
    def boxed(with_tag, with_code, frame=True, inner=PAPER, ink=INK):
        body = ""
        extra = 0
        if with_tag:
            extra = tag_gap + cap_tag + FR - FR + 6
        total_h = bh + (extra if with_tag else 0)
        if frame:
            body += f'<rect width="{f(bw)}" height="{f(total_h)}" fill="{ink}"/>'
        body += f'<rect x="{f(FR)}" y="{f(FR)}" width="{f(W + 2*PAD)}" height="{f(H)}" fill="{inner}"/>'
        body += f'<g transform="translate({f(FR + PAD)},{f(FR)})"><g transform="translate(0,{f(OVER)})"><path fill="{ink}" d="{wm_d}"/></g></g>'
        if with_tag:
            # tagline sits on the frame colour (paper on ink) below the box
            g = f'<g transform="translate(0,{f(bh - FR - OVER - CAP + 0)})">' if False else ""
            ty = bh + tag_gap * 0.55 + cap_tag - FR + 6
            fill = PAPER if frame else ink
            parts = []
            block_w = tag_w + ((CAP * 0.22) * 2 + div_w + code_w if with_code else 0)
            x0 = (bw - block_w) / 2
            parts.append(f'<path fill="{fill}" transform="translate({f(x0)},{f(ty)})" d="{tag_d}"/>')
            if with_code:
                xd = x0 + tag_w + CAP * 0.22
                parts.append(f'<rect fill="{fill}" x="{f(xd)}" y="{f(ty - cap_code - 3)}" width="{f(div_w)}" height="{f(cap_code + 6)}"/>')
                xc = xd + div_w + CAP * 0.22
                parts.append(f'<path fill="{fill}" transform="translate({f(xc)},{f(ty + 0.5)})" d="{code_d}"/>')
            body += "".join(parts)
        return svg(bw, total_h, body)

    write(os.path.join(svgdir, "ontech-boxed.svg"), boxed(False, False))
    write(os.path.join(svgdir, "ontech-boxed-tagline.svg"), boxed(True, False))
    write(os.path.join(svgdir, "ontech-boxed-primary.svg"), boxed(True, True))
    # box without frame, for dark backgrounds
    write(os.path.join(svgdir, "ontech-box-on-dark.svg"),
          svg(W + 2 * PAD, H, f'<rect width="{f(W + 2*PAD)}" height="{f(H)}" fill="{PAPER}"/>'
              f'<g transform="translate({f(PAD)},{f(OVER)})"><path fill="{INK}" d="{wm_d}"/></g>'))

    # 5. icon — the N device in its box, stem running to the frame (carries the device into the icon)
    def icon(size, ink, paper, frame_ratio=0.078, pad_ratio=0.16):
        FRi = size * frame_ratio
        inner = size - 2 * FRi
        # N scaled so that cap+over fits the inner box height minus top pad
        n_cap = inner * (1 - pad_ratio) / (1 + OVER / CAP)
        sc = n_cap / CAP
        wN = 61.0 * sc
        x0 = FRi + (inner - wN) / 2
        y0 = FRi + inner * pad_ratio  # top of cap; stem bottom lands exactly on the frame
        s, over, cap = S * sc, OVER * sc, CAP * sc
        d = (rect(x0, y0, s, cap + over) + rect(x0 + wN - s, y0, s, cap)
             + f"M{f(x0)},{f(y0)}h{f(14*sc)}L{f(x0+wN)},{f(y0+cap)}h{f(-14*sc)}z")
        body = (f'<rect width="{f(size)}" height="{f(size)}" fill="{ink}"/>'
                f'<rect x="{f(FRi)}" y="{f(FRi)}" width="{f(inner)}" height="{f(inner)}" fill="{paper}"/>'
                f'<path fill="{ink}" d="{d}"/>')
        return svg(size, size, body)
    write(os.path.join(svgdir, "ontech-icon.svg"), icon(512, INK, PAPER))
    write(os.path.join(svgdir, "ontech-icon-inverse.svg"), icon(512, PAPER, INK))
    # favicon-optimised: thicker frame, less padding so the N reads at 16 px
    write(os.path.join(svgdir, "ontech-favicon.svg"), icon(512, INK, PAPER, frame_ratio=0.11, pad_ratio=0.10))

    # 6. *388# standalone lockup (mono, accent) — product mark for the shortcode
    c_d, c_w = text_path("*388#", FONT_MONO, 100, tracking_em=0.0)
    padx, pady = 28, 22
    cw, ch = c_w + 2 * padx, 70 + 2 * pady
    for name, bg, fg in [("accent", ACCENT, INK), ("ink", INK, PAPER), ("outline", "none", INK)]:
        stroke = f' stroke="{INK}" stroke-width="4"' if name == "outline" else ""
        write(os.path.join(svgdir, f"ontech-388-{name}.svg"),
              svg(cw, ch, f'<rect x="2" y="2" width="{f(cw-4)}" height="{f(ch-4)}" rx="8" fill="{bg}"{stroke}/>'
                  f'<path fill="{fg}" transform="translate({f(padx)},{f(pady + 70)})" d="{c_d}"/>', title="*388#"))

    # construction sheet data
    spec = {
        "capHeight": CAP, "stem": S, "bar": B, "letterGap": GAP, "overshoot": OVER,
        "circleOuterRadius": R, "circleInnerRadius": RI, "cApertureHalfHeight": CUT,
        "letterAdvances": {l: a for l, _, a in letters}, "wordmarkWidth": W, "wordmarkHeight": H,
        "boxFrame": FR, "boxSidePadding": PAD, "ratios": {
            "stem/cap": round(S / CAP, 3), "bar/cap": round(B / CAP, 3), "gap/cap": round(GAP / CAP, 3),
            "overshoot/cap": round(OVER / CAP, 3), "width/cap": round(W / CAP, 3)}
    }
    write(os.path.join(ROOT, "logo", "construction.json"), json.dumps(spec, indent=2))
    return W, H


if __name__ == "__main__":
    print(build())
