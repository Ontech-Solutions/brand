import os, json, re
ROOT = os.path.join(os.path.dirname(__file__), "out", "ontech-brand")
svgdir = os.path.join(ROOT, "logo", "svg")
tokens = json.load(open(os.path.join(ROOT, "tokens", "tokens.json")))
tokens_css = open(os.path.join(ROOT, "tokens", "tokens.css")).read()
spec = json.load(open(os.path.join(ROOT, "logo", "construction.json")))

def svg(name, cls=""):
    s = open(os.path.join(svgdir, name + ".svg")).read()
    s = re.sub(r'\swidth="[^"]+"\sheight="[^"]+"', '', s, count=1)
    return s.replace("<svg ", f'<svg class="{cls}" ', 1)

N = tokens["color"]["neutral"]; SIG = tokens["color"]["signal"]; SEM = tokens["color"]["semantic"]; CH = tokens["color"]["chart"]
T = tokens["type"]["size"]

def sw(name, hexv, text=None, big=False):
    return (f'<div class="sw{" big" if big else ""}"><div class="chip" style="background:{hexv}"></div>'
            f'<div class="swl"><b>{name}</b><code>{hexv}</code>{("<span>"+text+"</span>") if text else ""}</div></div>')

neutral_sw = "".join(sw(k if k in ("ink","paper") else "neutral-"+k, v, big=False) for k, v in N.items())
signal_sw = "".join(sw(k, v, {"signal":"fills, CTAs, the *388# code","signal-strong":"accent text on paper","signal-soft":"highlight tint on paper","signal-dark":"accent on ink (dark mode)"}[k]) for k, v in SIG.items())
sem_rows = "".join(
    f'<tr><td class="semname">{k}</td>'
    f'<td><span class="pill" style="background:{v["soft"]};color:{v["text"]}">{k} text {v["text"]}</span></td>'
    f'<td><span class="dot" style="background:{v["fill"]}"></span><code>{v["fill"]}</code></td>'
    f'<td class="darkcell"><span class="pill" style="background:{v["dark-soft"]};color:{v["dark-text"]}">{k} text {v["dark-text"]}</span></td></tr>'
    for k, v in SEM.items())
chart_sw = "".join(f'<div class="cbar" style="background:{c};height:{100 - i*9}px" title="chart-{i+1} {c}"><span>{i+1}</span></div>' for i, c in enumerate(CH))
type_rows = "".join(
    f'<div class="trow"><div class="tmeta"><b>{k}</b><code>{v["px"]}px · {v["line"]} · {v["tracking"]} · {v["weight"]}</code></div>'
    f'<div class="tsample" style="font-family:{"var(--on-font-mono)" if v.get("family")=="mono" else "var(--on-font-display)"};font-size:{v["px"]}px;line-height:{v["line"]};letter-spacing:{v["tracking"]};font-weight:{v["weight"]};{"text-transform:uppercase;" if v.get("transform") else ""}">'
    + {"display":"Business systems that run on any phone.","h1":"Collections up 31% in Kitwe","h2":"Reach every customer, on any phone","h3":"Dial *388# to see it work","body":"Your agents collect from any phone. No app, no data bundle. Payments land in the ledger within 3 seconds, and the branch sees them the same minute.","small":"Go-live in 6 weeks. K120,000 fixed. Support from Lusaka, 07:00 to 19:00.","label":"Connect. Automate. Accelerate.","code":"*388# · TXN 0093-4471 · K2,400.00 · OK"}[k]
    + "</div></div>" for k, v in T.items())

html = f"""<title>ONTECH Brand Hub</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600&family=JetBrains+Mono:wght@500;600&display=swap">
<style>
{tokens_css}
:root {{ --gutter: 16px; }}
* {{ box-sizing: border-box; }}
body {{ margin:0; background: var(--on-bg); color: var(--on-fg); font-family: var(--on-font-ui); font-size: 16px; line-height: 1.55; padding-inline: var(--gutter); padding-block: 0 96px; -webkit-font-smoothing: antialiased; }}
a {{ color: inherit; }}
code {{ font-family: var(--on-font-mono); font-size: 0.8125rem; font-weight: 500; }}
.wrap {{ max-width: 1040px; margin: 0 auto; }}
header.top {{ display:flex; align-items:center; justify-content:space-between; gap:24px; padding-block: 20px; border-bottom: 1px solid var(--on-border); flex-wrap: wrap; }}
header.top .lg svg {{ height: 44px; width: auto; display:block; }}
header.top nav {{ display:flex; gap: 20px; flex-wrap: wrap; font-size: 0.875rem; }}
header.top nav a {{ text-decoration: none; color: var(--on-fg-muted); letter-spacing: 0.02em; }}
header.top nav a:hover {{ color: var(--on-fg); }}
.hero {{ padding-block: 56px 40px; display:grid; grid-template-columns: 1.2fr 1fr; gap: 40px; align-items:end; }}
.hero h1 {{ font-size: clamp(2rem, 5vw, 3.5rem); line-height: 1.05; letter-spacing: -0.02em; font-weight: 600; margin: 0 0 16px; text-wrap: balance; }}
.hero p {{ margin: 0; max-width: 34em; color: var(--on-fg-muted); }}
.stamp {{ display:inline-flex; align-items:center; gap:10px; font-size: 0.75rem; letter-spacing: 0.14em; text-transform: uppercase; font-weight: 500; color: var(--on-fg-muted); margin-bottom: 20px; }}
.stamp i {{ width: 10px; height: 10px; background: var(--on-accent); display:inline-block; }}
.hero .side {{ border: 1px solid var(--on-border); padding: 20px; font-size: 0.875rem; }}
.hero .side dl {{ display:grid; grid-template-columns: auto 1fr; gap: 6px 16px; margin: 0; }}
.hero .side dt {{ color: var(--on-fg-muted); }} .hero .side dd {{ margin:0; }}
section {{ padding-block: 48px; border-top: 1px solid var(--on-border); }}
section > h2 {{ font-size: 1.75rem; letter-spacing: -0.01em; font-weight: 600; margin: 0 0 6px; }}
section > .lead {{ margin: 0 0 28px; color: var(--on-fg-muted); max-width: 60ch; }}
.eyebrow {{ font-size: 0.75rem; letter-spacing: 0.14em; text-transform: uppercase; font-weight: 500; color: var(--on-fg-muted); margin: 0 0 8px; }}
.grid {{ display:grid; gap: 16px; }}
.g2 {{ grid-template-columns: repeat(2, 1fr); }} .g3 {{ grid-template-columns: repeat(3, 1fr); }}
.logo-tile {{ border: 1px solid var(--on-border); padding: 28px; display:flex; flex-direction:column; gap: 18px; min-height: 200px; justify-content: space-between; }}
.logo-tile.dark {{ background: var(--on-ink); color: var(--on-paper); border-color: var(--on-ink); }}
.logo-tile.light {{ background: var(--on-paper); color: var(--on-ink); border-color: var(--on-neutral-300); }}
.logo-tile svg {{ width: 100%; height: auto; max-height: 140px; display:block; }}
.logo-tile .cap {{ font-size: 0.8125rem; display:flex; justify-content:space-between; gap: 12px; opacity: 0.8; }}
.logo-tile .cap code {{ opacity: 0.9; }}
.master {{ grid-column: 1 / -1; background: var(--on-ink); border-color: var(--on-ink); color: var(--on-paper); display:grid; grid-template-columns: 1.1fr 1fr; gap: 32px; align-items:center; padding: 40px; }}
.master svg {{ width: 100%; max-height: none; }}
.master h3 {{ margin: 0 0 8px; font-size: 1.25rem; }} .master p {{ margin: 0 0 10px; font-size: 0.9375rem; opacity: 0.85; }}
.icons {{ display:flex; gap: 20px; align-items:flex-end; flex-wrap: wrap; }}
.icons figure {{ margin:0; text-align:center; font-size: 0.75rem; color: var(--on-fg-muted); }}
.icons svg {{ display:block; margin: 0 auto 6px; }}
.construct {{ display:grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items:center; }}
.construct table {{ width:100%; border-collapse: collapse; font-size: 0.875rem; }}
.construct td {{ padding: 8px 0; border-bottom: 1px solid var(--on-border); }} .construct td:last-child {{ text-align:right; font-family: var(--on-font-mono); font-size: 0.8125rem; }}
.swatches {{ display:grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 12px; }}
.sw .chip {{ height: 64px; border: 1px solid var(--on-border); }}
.sw.big .chip {{ height: 96px; }}
.swl {{ display:flex; flex-direction:column; font-size: 0.8125rem; padding-top: 6px; gap: 2px; }} .swl span {{ color: var(--on-fg-muted); }}
.semtab {{ width: 100%; border-collapse: collapse; font-size: 0.875rem; }}
.semtab td, .semtab th {{ padding: 10px 12px; border-bottom: 1px solid var(--on-border); text-align:left; vertical-align: middle; }}
.semtab th {{ font-size: 0.75rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--on-fg-muted); font-weight: 500; }}
.semname {{ text-transform: capitalize; font-weight: 500; }}
.pill {{ display:inline-block; padding: 3px 10px; border-radius: 999px; font-size: 0.8125rem; font-weight: 500; white-space: nowrap; }}
.dot {{ display:inline-block; width: 14px; height: 14px; border-radius: 50%; vertical-align: -2px; margin-right: 8px; }}
.darkcell {{ background: var(--on-ink); }}
.chartrow {{ display:flex; gap: 8px; align-items:flex-end; height: 110px; }}
.cbar {{ flex:1; display:flex; align-items:flex-end; justify-content:center; color: #111; font-family: var(--on-font-mono); font-size: 0.75rem; padding-bottom: 4px; }}
.cbar:nth-child(n+2) span {{ color: #fff; }} .cbar:nth-child(4) span {{ color: #111; }}
.rules {{ counter-reset: r; display:grid; gap: 12px; margin: 0; padding: 0; list-style:none; max-width: 70ch; }}
.rules li {{ counter-increment: r; display:grid; grid-template-columns: 32px 1fr; gap: 12px; font-size: 0.9375rem; }}
.rules li::before {{ content: counter(r, decimal-leading-zero); font-family: var(--on-font-mono); font-size: 0.75rem; color: var(--on-accent-text); padding-top: 4px; }}
.trow {{ display:grid; grid-template-columns: 200px 1fr; gap: 20px; padding: 18px 0; border-bottom: 1px solid var(--on-border); align-items: baseline; }}
.tmeta {{ display:flex; flex-direction:column; gap: 4px; font-size: 0.875rem; }} .tmeta code {{ color: var(--on-fg-muted); font-size: 0.75rem; }}
.tsample {{ overflow-wrap: anywhere; max-width: 32em; }}
.voice {{ display:grid; grid-template-columns: 1fr 1fr; gap: 32px; }}
.voice table {{ width: 100%; border-collapse: collapse; font-size: 0.875rem; }}
.voice td {{ padding: 8px 10px 8px 0; border-bottom: 1px solid var(--on-border); vertical-align: top; }}
.voice td:first-child {{ color: var(--on-fg-muted); text-decoration: line-through; width: 40%; }}
.pos {{ background: var(--on-ink); color: var(--on-paper); padding: 32px; margin: 24px 0; display:grid; gap: 8px; }}
.pos .big {{ font-size: clamp(1.5rem, 3vw, 2.25rem); font-weight: 600; letter-spacing: -0.015em; line-height: 1.1; text-wrap: balance; }}
.pos .accent {{ color: var(--on-signal-dark); }}
.demo {{ display:grid; grid-template-columns: 1fr 1fr; gap: 16px; }}
.card {{ border: 1px solid var(--on-border); padding: 20px; display:flex; flex-direction: column; gap: 14px; }}
.card.dark {{ background: var(--on-ink); color: var(--on-paper); border-color: var(--on-ink); }}
.btn {{ display:inline-flex; align-items:center; gap: 8px; padding: 10px 16px; font: 500 0.9375rem var(--on-font-ui); border: 0; cursor: pointer; }}
.btn.primary {{ background: var(--on-signal); color: var(--on-ink); box-shadow: inset 0 0 0 1.5px var(--on-ink); }}
.card.dark .btn.primary {{ box-shadow: none; background: var(--on-signal-dark); }}
.btn.ghost {{ background: transparent; color: inherit; box-shadow: inset 0 0 0 1px currentColor; }}
.btn:focus-visible {{ outline: 2px solid var(--on-accent); outline-offset: 2px; }}
.stat {{ display:flex; gap: 24px; }} .stat div b {{ display:block; font-size: 1.75rem; font-weight: 600; letter-spacing: -0.01em; font-variant-numeric: tabular-nums; }} .stat div span {{ font-size: 0.75rem; letter-spacing: 0.1em; text-transform: uppercase; opacity: 0.7; }}
.status {{ display:flex; gap: 8px; flex-wrap: wrap; }}
.ussd {{ font-family: var(--on-font-mono); font-size: 0.875rem; background: var(--on-neutral-100); color: var(--on-ink); padding: 14px; white-space: pre; line-height: 1.5; border-left: 3px solid var(--on-signal); }}
.card.dark .ussd {{ background: var(--on-neutral-900); color: var(--on-paper); }}
.files {{ font-size: 0.875rem; display:grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 8px 24px; }}
.files code {{ display:block; }}
.assump {{ border-left: 3px solid var(--on-signal); padding: 4px 16px 4px 36px; margin: 0; }}
.assump li {{ margin: 6px 0; }}
footer {{ padding-top: 32px; font-size: 0.8125rem; color: var(--on-fg-muted); border-top: 1px solid var(--on-border); display:flex; justify-content: space-between; gap: 16px; flex-wrap: wrap; }}
@media (max-width: 760px) {{
  .hero, .master, .construct, .voice, .demo, .g2, .g3 {{ grid-template-columns: 1fr; }}
  .trow {{ grid-template-columns: 1fr; gap: 8px; }}
  .master {{ padding: 24px; }}
}}
@media (prefers-reduced-motion: no-preference) {{ .btn {{ transition: transform 120ms cubic-bezier(0.32,0,0.15,1); }} .btn:active {{ transform: translateY(1px); }} }}
</style>
<div class="wrap">
<header class="top">
  <div class="lg">{svg("ontech-boxed")}</div>
  <nav><a href="#logo">Logo</a><a href="#colour">Colour</a><a href="#type">Type</a><a href="#voice">Voice</a><a href="#ui">In use</a><a href="#files">Files</a></nav>
</header>

<div class="hero">
  <div>
    <div class="stamp"><i></i> Brand system v1.0 · Phase 1 · 27 Sep 2026</div>
    <h1>One mark, now a system.</h1>
    <p>The ONTECH wordmark redrawn from geometry, one signal colour, a type scale, semantic colours for product UI, and a voice. Everything below is a token in the repo, not a picture of one.</p>
  </div>
  <div class="side">
    <dl>
      <dt>Ink</dt><dd><code>#111111</code> unchanged</dd>
      <dt>Paper</dt><dd><code>#FFFFFF</code> unchanged</dd>
      <dt>Signal</dt><dd><code>#F5A524</code> new, one only</dd>
      <dt>Type</dt><dd>Jost 400/500/600 · JetBrains Mono 500/600</dd>
      <dt>Master logo</dt><dd>Boxed device</dd>
      <dt>Contrast</dt><dd>33 pairs checked, 0 fail</dd>
    </dl>
  </div>
</div>

<section id="logo">
  <h2>Logo</h2>
  <p class="lead">The boxed device is now the master: it is the most distinctive form of the mark and the state the logo sting resolves to. The N stroke runs to the bottom of the frame, the H stroke to the top. Nothing about the letterforms changed; they are now built from circles and rectangles instead of a trace.</p>
  <div class="grid g2">
    <div class="logo-tile master">
      <div>{svg("ontech-boxed-primary")}</div>
      <div><h3>Master lockup</h3><p>Boxed wordmark with tagline and shortcode. Use on anything where ONTECH is the sender: proposals, decks, site header, video end-card.</p><p><code>ontech-boxed-primary.svg</code></p></div>
    </div>
    <div class="logo-tile light">{svg("ontech-primary-on-light")}<div class="cap"><span>Primary, on light</span><code>ontech-primary-on-light</code></div></div>
    <div class="logo-tile dark">{svg("ontech-primary-on-dark")}<div class="cap"><span>Primary, on dark</span><code>ontech-primary-on-dark</code></div></div>
    <div class="logo-tile light">{svg("ontech-wordmark-on-light")}<div class="cap"><span>Wordmark, small spaces</span><code>ontech-wordmark-on-light</code></div></div>
    <div class="logo-tile dark">{svg("ontech-box-on-dark")}<div class="cap"><span>Box without frame, on dark</span><code>ontech-box-on-dark</code></div></div>
  </div>
  <div style="height:32px"></div>
  <div class="construct">
    <div>
      <p class="eyebrow">Construction</p>
      <table>
        <tr><td>Cap height</td><td>{spec["capHeight"]:g}</td></tr>
        <tr><td>Stem width</td><td>{spec["stem"]:g} · {spec["ratios"]["stem/cap"]} cap</td></tr>
        <tr><td>Bar width</td><td>{spec["bar"]:g} · {spec["ratios"]["bar/cap"]} cap</td></tr>
        <tr><td>Letter gap</td><td>{spec["letterGap"]:g} · {spec["ratios"]["gap/cap"]} cap</td></tr>
        <tr><td>N descender / H ascender</td><td>{spec["overshoot"]:g} · {spec["ratios"]["overshoot/cap"]} cap</td></tr>
        <tr><td>O and C circle</td><td>r {spec["circleOuterRadius"]:g} outer, {spec["circleInnerRadius"]:g} inner</td></tr>
        <tr><td>C aperture</td><td>horizontal terminals ±{spec["cApertureHalfHeight"]:g}</td></tr>
        <tr><td>Wordmark</td><td>{spec["wordmarkWidth"]:g} × {spec["wordmarkHeight"]:g} · {spec["ratios"]["width/cap"]} cap</td></tr>
        <tr><td>Box frame / side pad</td><td>{spec["boxFrame"]:g} / {spec["boxSidePadding"]:g}</td></tr>
      </table>
      <p style="font-size:0.875rem;color:var(--on-fg-muted);margin:12px 0 0">All values in <code>logo/construction.json</code>. Change the cap height and the generator rebuilds every file.</p>
    </div>
    <div>
      <p class="eyebrow">Icons</p>
      <div class="icons">
        <figure>{svg("ontech-icon").replace('class="', 'width="96" height="96" class="')}<figcaption>Icon 1024</figcaption></figure>
        <figure>{svg("ontech-icon-inverse").replace('class="', 'width="96" height="96" class="')}<figcaption>Inverse</figcaption></figure>
        <figure>{svg("ontech-favicon").replace('class="', 'width="48" height="48" class="')}<figcaption>Favicon 48</figcaption></figure>
        <figure>{svg("ontech-favicon").replace('class="', 'width="32" height="32" class="')}<figcaption>32</figcaption></figure>
        <figure>{svg("ontech-favicon").replace('class="', 'width="16" height="16" class="')}<figcaption>16</figcaption></figure>
      </div>
      <p class="eyebrow" style="margin-top:28px">*388# product mark</p>
      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">
        {svg("ontech-388-accent").replace('class="', 'height="56" class="')}
        {svg("ontech-388-ink").replace('class="', 'height="56" class="')}
        {svg("ontech-388-outline").replace('class="', 'height="56" class="')}
      </div>
      <p style="font-size:0.875rem;color:var(--on-fg-muted);margin:12px 0 0">The shortcode set in JetBrains Mono, so it reads as something you dial. Stickers, posters, USSD screens. Never replaces the ONTECH logo on a page; sits beside it.</p>
    </div>
  </div>
</section>

<section id="colour">
  <h2>Colour</h2>
  <p class="lead">Ink and paper stay the brand. One warm signal colour marks what is live: a call to action, an active state, the shortcode. Neutrals are warm-tinted so they sit with it. Semantic colours exist only for product UI.</p>
  <p class="eyebrow">Neutrals</p>
  <div class="swatches">{neutral_sw}</div>
  <p class="eyebrow" style="margin-top:32px">Signal</p>
  <div class="swatches">{signal_sw}</div>
  <p class="eyebrow" style="margin-top:32px">Semantic (product UI only)</p>
  <div style="overflow-x:auto"><table class="semtab">
    <thead><tr><th>Role</th><th>Text on soft, light</th><th>Fill</th><th>Text on soft, dark</th></tr></thead>
    <tbody>{sem_rows}</tbody>
  </table></div>
  <p class="eyebrow" style="margin-top:32px">Chart order</p>
  <div class="chartrow">{chart_sw}</div>
  <p style="font-size:0.875rem;color:var(--on-fg-muted);margin:12px 0 0">Series take colours in this order. Signal first, so the brand's colour is the series that matters.</p>
  <p class="eyebrow" style="margin-top:32px">Rules</p>
  <ol class="rules">
    <li><span>Body text is ink on paper or paper on ink. Never on the signal colour.</span></li>
    <li><span>Signal text on paper uses <code>signal-strong</code> (5.9:1). The raw amber fails 3:1 on white, so on paper it is a fill that carries an ink label or an ink border, or it sits on ink.</span></li>
    <li><span>One accent per screen. If two things are amber, one of them is not important.</span></li>
    <li><span>Dark mode uses the <code>-dark</code> pairs, never the light values inverted.</span></li>
    <li><span>Semantic colours (success, warning, error, info) are for state in product UI. They never appear in marketing.</span></li>
  </ol>
</section>

<section id="type">
  <h2>Type</h2>
  <p class="lead">Jost everywhere, the face already in the tagline. JetBrains Mono for anything a person dials, pays or copies: shortcodes, amounts, references, transaction IDs. Eight sizes; nothing outside them.</p>
  {type_rows}
  <p style="font-size:0.875rem;color:var(--on-fg-muted);margin:16px 0 0">Tabular figures in every table and amount (<code>font-variant-numeric: tabular-nums</code>). Labels are uppercase and tracked 0.14em, the same treatment as the tagline in the logo.</p>
</section>

<section id="voice">
  <h2>Voice</h2>
  <p class="lead">Precise, local, fast. The logo is engineered; the writing should read like it was too. Lead with the outcome, say the number, name the place.</p>
  <div class="pos">
    <div class="eyebrow" style="color:var(--on-neutral-400)">Positioning line · draft, to test with 5 customers</div>
    <div class="big">Business systems that run on <span class="accent">any phone</span> in Zambia.</div>
    <div style="font-size:0.875rem;opacity:0.8">Sits under the tagline on the site and opens every proposal. Fallback if the claim is too narrow: "Business systems built in Zambia, for Zambia."</div>
  </div>
  <div class="voice">
    <div>
      <p class="eyebrow">Ten rules</p>
      <ol class="rules">
        <li><span>Lead with the outcome, then how.</span></li>
        <li><span>Verbs over nouns. The tagline is three verbs.</span></li>
        <li><span>One idea per sentence, under 20 words.</span></li>
        <li><span>Numbers as figures: 31%, K2.4m, 12 branches.</span></li>
        <li><span>Plain words. Use, not utilise. Help, not empower.</span></li>
        <li><span>No metaphor that is not literally true.</span></li>
        <li><span>Say who it is for: "MFIs with 5 to 50 loan officers."</span></li>
        <li><span>Products are ONTECH + descriptor, in Jost. No second logos.</span></li>
        <li><span>ONTECH in caps in copy; Ontech only in the legal name and URLs.</span></li>
        <li><span>We and you. Never "the client".</span></li>
      </ol>
    </div>
    <div>
      <p class="eyebrow">Before and after</p>
      <table>
        <tr><td>We leave a signature of Excellence on every Client</td><td>Business systems that run on any phone in Zambia.</td></tr>
        <tr><td>a symphony of customizable voice technologies</td><td>Reach every customer, on any phone. USSD, SMS, voice and a contact centre, from one provider.</td></tr>
        <tr><td>digital sentinel</td><td>Keep running when things go wrong. Backups and disaster recovery, tested with you every quarter.</td></tr>
        <tr><td>end-to-end technology enabler specializing in digital transformation</td><td>ERP, CRM and USSD services for banks, insurers, MFIs and government. Built and supported from Lusaka.</td></tr>
        <tr><td>Local Expertise, Global Standards</td><td>PCI-DSS hosted in Lusaka.</td></tr>
      </table>
      <p style="font-size:0.875rem;color:var(--on-fg-muted);margin:12px 0 0">Full guide with every service line rewritten: <code>guidelines/voice.md</code></p>
    </div>
  </div>
</section>

<section id="ui">
  <h2>In use</h2>
  <p class="lead">The same tokens on a light product card, a dark marketing card and a USSD screen.</p>
  <div class="demo">
    <div class="card">
      <div class="eyebrow">ONTECH CRM · Collections</div>
      <div class="stat"><div><b>K2.41m</b><span>Collected this week</span></div><div><b>31%</b><span>vs last week</span></div><div><b>12</b><span>Branches</span></div></div>
      <div class="status">
        <span class="pill" style="background:{SEM['success']['soft']};color:{SEM['success']['text']}">● 1,204 paid</span>
        <span class="pill" style="background:{SEM['warning']['soft']};color:{SEM['warning']['text']}">● 88 due today</span>
        <span class="pill" style="background:{SEM['error']['soft']};color:{SEM['error']['text']}">● 14 failed</span>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn primary" id="b1" type="button">Send reminders</button><button class="btn ghost" id="b2" type="button">Export</button></div>
    </div>
    <div class="card dark">
      <div class="eyebrow" style="color:var(--on-neutral-400)">Marketing</div>
      <div style="font-size:1.5rem;font-weight:600;letter-spacing:-0.015em;line-height:1.15;text-wrap:balance">Your agents collect from any phone. No app, no data bundle.</div>
      <div class="ussd">ONTECH  *388#
1. Check balance
2. Pay loan
3. Talk to us
0. Back</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn primary" id="b3" type="button">Dial *388#</button><button class="btn ghost" id="b4" type="button">Talk to an engineer</button></div>
    </div>
  </div>
</section>

<section id="files">
  <h2>Files</h2>
  <p class="lead">Everything on this page is generated from three scripts. Edit the numbers, rerun, and every file updates.</p>
  <div class="files">
    <div><code>logo/svg/</code>16 SVG masters (geometric, outlines)</div>
    <div><code>logo/png/</code>600, 1200, 2400 px of each lockup</div>
    <div><code>logo/icons/</code>favicon.ico, .svg, 16–1024, webmanifest</div>
    <div><code>logo/construction.json</code>every ratio of the mark</div>
    <div><code>tokens/tokens.json</code>colour, type, space, radius, motion</div>
    <div><code>tokens/tokens.css</code>CSS variables, light and dark</div>
    <div><code>tokens/contrast-report.md</code>33 WCAG pairs</div>
    <div><code>guidelines/voice.md</code>voice, rewritten copy, tone by surface</div>
    <div><code>tools/gen_logo.py · gen_tokens.py · gen_hub.py</code>generators</div>
  </div>
  <p class="eyebrow" style="margin-top:32px">Assumptions to confirm</p>
  <ul class="assump">
    <li>Boxed device as master logo (the plain wordmark stays as a secondary).</li>
    <li>Warm amber as the one signal colour. A cool cyan was the alternative.</li>
    <li>N descender and H ascender made equal (0.44 cap); the trace had 0.42 and 0.47.</li>
    <li>*388# treated as a product with its own mark, pending what it actually is.</li>
    <li>The positioning line is a draft claim, not signed off.</li>
  </ul>
</section>

<footer><span>ONTECH brand system v1.0.0 · generated 2026-09-27</span><span>Jost (OFL) · JetBrains Mono (OFL)</span></footer>
</div>
"""
os.makedirs(os.path.join(ROOT, "hub"), exist_ok=True)
open(os.path.join(ROOT, "hub", "index.html"), "w").write(html)
print(len(html))
