import os, re
ROOT = os.path.join(os.path.dirname(__file__), "out", "ontech-brand")
tokens_css = open(os.path.join(ROOT, "tokens", "tokens.css")).read()
def svg(name):
    s = open(os.path.join(ROOT, "logo", "svg", name + ".svg")).read()
    return re.sub(r'\s(width|height)="[^"]+"', '', s, count=2)

services = [
    ("Software", "Run your operation on one system.", "ERP, CRM and finance, built for how Zambian companies actually work. Loan books, policies, payroll, stock. Hosted in Lusaka or on your own servers.", "ONTECH CRM"),
    ("Communications", "Reach every customer, on any phone.", "USSD, SMS, voice and a contact centre, from one provider. Dial *388# to see it work. Messages in English, Bemba or Nyanja.", "ONTECH Connect"),
    ("Security and continuity", "Keep running when things go wrong.", "Risk management, backups and disaster recovery, tested with you every quarter, not written once and filed.", "ONTECH Guard"),
    ("Infrastructure", "Your servers, our racks in Lusaka.", "Migration, hosting, colocation and maintenance without the international latency or the dollar invoice.", "ONTECH Cloud"),
    ("Outsourcing", "Hand us the back office.", "Contact centre, data capture and campaigns, staffed in Zambia, reported weekly.", "ONTECH BPO"),
    ("Equipment", "Kit for the project, not forever.", "Laptops, network gear and office machines by the month. Delivered, configured, collected.", "ONTECH Rent"),
]
cards = "".join(f'''<article class="svc"><div class="svc-k">{k}</div><h3>{h}</h3><p>{p}</p><div class="svc-p">{n}</div></article>''' for k, h, p, n in services)

html = f"""<title>ONTECH Website</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600&family=JetBrains+Mono:wght@500;600&display=swap">
<style>
{tokens_css}
* {{ box-sizing: border-box; }}
html {{ scroll-behavior: smooth; }}
body {{ margin: 0; background: var(--on-bg); color: var(--on-fg); font-family: var(--on-font-ui); font-size: 17px; line-height: 1.55; -webkit-font-smoothing: antialiased; padding-inline: 0; }}
a {{ color: inherit; }}
.wrap {{ max-width: 1120px; margin: 0 auto; padding-inline: 20px; }}
.mono {{ font-family: var(--on-font-mono); font-variant-numeric: tabular-nums; }}
.eyebrow {{ font-size: 0.75rem; letter-spacing: 0.14em; text-transform: uppercase; font-weight: 500; color: var(--on-fg-muted); }}
.btn {{ display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; font: 500 0.9375rem var(--on-font-ui); text-decoration: none; border: 1px solid transparent; cursor: pointer; }}
.btn-primary {{ background: var(--on-signal); color: var(--on-ink); border-color: var(--on-ink); }}
.btn-ghost {{ border-color: currentColor; background: transparent; }}
.btn:focus-visible {{ outline: 2px solid var(--on-accent); outline-offset: 2px; }}

header.site {{ position: sticky; top: env(safe-area-inset-top, 0px); z-index: 10; background: var(--on-bg); border-bottom: 1px solid var(--on-border); }}
header.site .wrap {{ display: flex; align-items: center; justify-content: space-between; gap: 24px; height: 64px; }}
header.site svg {{ height: 34px; width: auto; display: block; }}
header.site nav {{ display: flex; gap: 22px; font-size: 0.9375rem; font-weight: 500; }}
header.site nav a {{ text-decoration: none; color: var(--on-fg-muted); }}
header.site nav a:hover {{ color: var(--on-fg); }}
header.site .dial {{ font-family: var(--on-font-mono); font-weight: 600; color: var(--on-accent-text); text-decoration: none; }}

.hero {{ background: var(--on-ink); color: var(--on-paper); }}
.hero .wrap {{ display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 48px; align-items: center; padding-block: 88px; }}
.hero h1 {{ font-size: clamp(2.25rem, 5.2vw, 3.75rem); line-height: 1.04; letter-spacing: -0.02em; font-weight: 600; margin: 0 0 20px; text-wrap: balance; }}
.hero h1 em {{ font-style: normal; color: var(--on-signal-dark); }}
.hero p {{ font-size: 1.125rem; color: var(--on-neutral-400); margin: 0 0 32px; max-width: 34em; }}
.hero .cta {{ display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }}
.hero .btn-primary {{ border-color: transparent; background: var(--on-signal-dark); }}
.hero .btn-ghost {{ color: var(--on-paper); }}
.phone {{ justify-self: center; width: 300px; max-width: 100%; background: var(--on-neutral-900); border: 1px solid var(--on-neutral-700); border-radius: 28px; padding: 18px 16px 24px; }}
.phone .screen {{ background: var(--on-neutral-100); color: var(--on-ink); padding: 18px 16px; font-family: var(--on-font-mono); font-size: 0.875rem; line-height: 1.6; white-space: pre; border-bottom: 5px solid var(--on-signal); min-height: 220px; }}
.phone .keys {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-top: 16px; }}
.phone .keys span {{ height: 26px; background: var(--on-neutral-800); border-radius: 6px; }}
.phone .cap {{ margin-top: 14px; font-size: 0.75rem; color: var(--on-neutral-400); text-align: center; }}

.proof {{ border-bottom: 1px solid var(--on-border); }}
.proof .wrap {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; padding-block: 40px; }}
.proof b {{ display: block; font-size: 2rem; font-weight: 600; letter-spacing: -0.015em; line-height: 1.05; font-variant-numeric: tabular-nums; }}
.proof span {{ font-size: 0.875rem; color: var(--on-fg-muted); }}
.proof .first b {{ color: var(--on-accent-text); }}

section {{ padding-block: 80px; }}
section > .wrap > h2 {{ font-size: clamp(1.75rem, 3.2vw, 2.5rem); letter-spacing: -0.015em; font-weight: 600; margin: 8px 0 12px; text-wrap: balance; }}
section .lead {{ color: var(--on-fg-muted); max-width: 40em; margin: 0 0 40px; font-size: 1.0625rem; }}
.svcs {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 1px; background: var(--on-border); border: 1px solid var(--on-border); }}
.svc {{ background: var(--on-bg); padding: 28px; display: flex; flex-direction: column; gap: 10px; min-height: 260px; }}
.svc .svc-k {{ font-size: 0.75rem; letter-spacing: 0.14em; text-transform: uppercase; font-weight: 500; color: var(--on-fg-muted); }}
.svc h3 {{ margin: 0; font-size: 1.25rem; font-weight: 600; letter-spacing: -0.01em; }}
.svc p {{ margin: 0; font-size: 0.9375rem; color: var(--on-fg-muted); flex: 1; }}
.svc .svc-p {{ font-size: 0.8125rem; font-weight: 500; color: var(--on-accent-text); }}
.svc:hover {{ background: var(--on-bg-subtle); }}

.how {{ background: var(--on-bg-subtle); }}
.steps {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 32px; }}
.step .n {{ font-family: var(--on-font-mono); color: var(--on-accent-text); font-size: 0.875rem; font-weight: 600; }}
.step h3 {{ margin: 8px 0 6px; font-size: 1.125rem; }}
.step p {{ margin: 0; color: var(--on-fg-muted); font-size: 0.9375rem; }}

.case {{ background: var(--on-ink); color: var(--on-paper); }}
.case .wrap {{ display: grid; grid-template-columns: 1fr 1fr; gap: 48px; align-items: center; }}
.case blockquote {{ margin: 0; font-size: clamp(1.375rem, 2.4vw, 1.75rem); font-weight: 500; line-height: 1.3; letter-spacing: -0.01em; }}
.case blockquote::before {{ content: "\\201C"; display: block; color: var(--on-signal-dark); font-size: 4rem; line-height: 0.6; margin-bottom: 18px; font-weight: 600; }}
.case cite {{ display: block; font-style: normal; color: var(--on-neutral-400); font-size: 0.9375rem; margin-top: 20px; }}
.case dl {{ display: grid; grid-template-columns: auto 1fr; gap: 12px 20px; margin: 0; font-size: 0.9375rem; }}
.case dt {{ color: var(--on-neutral-400); }} .case dd {{ margin: 0; }}
.case .eyebrow {{ color: var(--on-neutral-400); margin-bottom: 20px; display: block; }}

.who .logos {{ display: flex; gap: 12px; flex-wrap: wrap; }}
.who .logos span {{ border: 1px solid var(--on-border); padding: 8px 14px; font-size: 0.875rem; color: var(--on-fg-muted); }}

.contact .wrap {{ display: grid; grid-template-columns: 1fr 1fr; gap: 48px; }}
.contact form {{ display: grid; gap: 14px; }}
.contact label {{ display: grid; gap: 6px; font-size: 0.875rem; font-weight: 500; }}
.contact input, .contact select, .contact textarea {{ font: 400 1rem var(--on-font-ui); padding: 10px 12px; border: 1px solid var(--on-neutral-400); background: var(--on-bg); color: var(--on-fg); width: 100%; }}
.contact input:focus, .contact select:focus, .contact textarea:focus {{ outline: 2px solid var(--on-accent); border-color: var(--on-fg); }}
.contact .direct {{ display: grid; gap: 18px; align-content: start; }}
.contact .direct div {{ display: grid; gap: 2px; }}
.contact .direct .v {{ font-size: 1.25rem; font-weight: 500; }}
.contact .direct .v.mono {{ color: var(--on-accent-text); font-weight: 600; }}
.contact .ok {{ display: none; padding: 12px 14px; background: var(--on-success-soft-role); color: var(--on-success-text-role); font-size: 0.9375rem; }}
.contact .ok.show {{ display: block; }}

footer.site {{ background: var(--on-ink); color: var(--on-neutral-400); font-size: 0.875rem; }}
footer.site .wrap {{ display: grid; grid-template-columns: 1.2fr 1fr 1fr 1fr; gap: 32px; padding-block: 56px 40px; }}
footer.site svg {{ width: 200px; height: auto; display: block; margin-bottom: 16px; }}
footer.site h4 {{ margin: 0 0 10px; color: var(--on-paper); font-size: 0.8125rem; letter-spacing: 0.1em; text-transform: uppercase; font-weight: 500; }}
footer.site ul {{ list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }}
footer.site a {{ text-decoration: none; }} footer.site a:hover {{ color: var(--on-paper); }}
footer.site .legal {{ border-top: 1px solid var(--on-neutral-800); padding-block: 18px; font-size: 0.75rem; display: flex; justify-content: space-between; gap: 16px; flex-wrap: wrap; }}

@media (max-width: 900px) {{
  .hero .wrap, .case .wrap, .contact .wrap {{ grid-template-columns: 1fr; }}
  .svcs, .steps {{ grid-template-columns: 1fr 1fr; }}
  .proof .wrap {{ grid-template-columns: 1fr 1fr; }}
  footer.site .wrap {{ grid-template-columns: 1fr 1fr; }}
  header.site nav {{ display: none; }}
}}
@media (max-width: 560px) {{ .svcs, .steps, .proof .wrap, footer.site .wrap {{ grid-template-columns: 1fr; }} section {{ padding-block: 56px; }} .hero .wrap {{ padding-block: 56px; }} }}
@media (prefers-reduced-motion: reduce) {{ html {{ scroll-behavior: auto; }} }}
</style>

<header class="site"><div class="wrap">
  <a href="#top" aria-label="ONTECH home">{svg("ontech-boxed")}</a>
  <nav><a href="#services">Services</a><a href="#how">How it works</a><a href="#case">Customers</a><a href="#contact">Contact</a></nav>
  <a class="dial" href="#contact">*388#</a>
</div></header>

<section class="hero" id="top"><div class="wrap">
  <div>
    <div class="eyebrow" style="color:var(--on-neutral-400);margin-bottom:18px">Connect. Automate. Accelerate.</div>
    <h1>Business systems that run on <em>any phone</em> in Zambia.</h1>
    <p>ERP, CRM and USSD services for banks, insurers, MFIs and government. Built and supported from Lusaka. If your customers have a phone, they can use it.</p>
    <div class="cta"><a class="btn btn-primary" href="#contact">Talk to an engineer</a><a class="btn btn-ghost" href="#how">See how *388# works</a></div>
  </div>
  <div class="phone" aria-label="USSD demo screen">
    <div class="screen">ONTECH  *388#
Kwacha MFI
1. Check balance
2. Pay loan
3. Talk to us
0. Back</div>
    <div class="keys"><span></span><span></span><span></span><span></span><span></span><span></span></div>
    <div class="cap">Works on a K150 phone. No app, no data bundle.</div>
  </div>
</div></section>

<div class="proof"><div class="wrap">
  <div class="first"><b>31%</b><span>more collected per agent, median across 12 MFIs</span></div>
  <div><b>3 s</b><span>from USSD confirmation to the ledger</span></div>
  <div><b>6 wk</b><span>signed to first live payment, median</span></div>
  <div><b>Lusaka</b><span>hosting, support and every engineer</span></div>
</div></div>

<section id="services"><div class="wrap">
  <div class="eyebrow">Services</div>
  <h2>Six things we do. Each one has a phone number.</h2>
  <p class="lead">Every service is run by an engineer you can call. Product names are plain: ONTECH plus what it does.</p>
  <div class="svcs">{cards}</div>
</div></section>

<section class="how" id="how"><div class="wrap">
  <div class="eyebrow">How *388# works</div>
  <h2>From a dialled code to your ledger in three seconds.</h2>
  <p class="lead">USSD runs on the network, not the internet. That is why it works on every phone in the country.</p>
  <div class="steps">
    <div class="step"><div class="n">01</div><h3>Your customer dials *388#</h3><p>A numbered menu with your name on it. Balance, pay, talk to us. Under 160 characters a screen, in English, Bemba or Nyanja.</p></div>
    <div class="step"><div class="n">02</div><h3>Mobile money confirms</h3><p>MTN or Airtel Money takes the payment with a PIN. No card, no app, no bundle. The customer gets an SMS receipt.</p></div>
    <div class="step"><div class="n">03</div><h3>Your system updates</h3><p>The payment posts to ONTECH CRM or your own core system within 3 seconds. Your branch sees it the same minute.</p></div>
  </div>
</div></section>

<section class="case" id="case"><div class="wrap">
  <div>
    <span class="eyebrow">Customer · Copperbelt MFI</span>
    <blockquote>The agents did not believe it until the first Friday. Then nobody wanted to go back to the motorbike.<cite>Operations manager, Copperbelt MFI</cite></blockquote>
  </div>
  <dl>
    <dt>Before</dt><dd>K1.6m collected per month, 38 agents, 4 days to reconcile</dd>
    <dt>Change</dt><dd>*388# payments, SMS reminders 2 days before due, ONTECH CRM at every branch</dd>
    <dt>After</dt><dd>K2.3m per month, same agents, reconciled by 09:00 next day</dd>
    <dt>Time</dt><dd>Signed 3 March, live 14 April 2026</dd>
  </dl>
</div></section>

<section class="who"><div class="wrap">
  <div class="eyebrow">Who we work with</div>
  <h2>Banks, insurers, microfinance, government and schools.</h2>
  <p class="lead">Mostly organisations with between 5 and 500 staff who need one system that their customers can reach from any phone.</p>
  <div class="logos"><span>Commercial banks</span><span>Microfinance lenders</span><span>Insurers</span><span>Government agencies</span><span>Colleges and schools</span><span>SACCOs</span></div>
</div></section>

<section class="contact" id="contact"><div class="wrap">
  <div>
    <div class="eyebrow">Contact</div>
    <h2 style="font-size:clamp(1.75rem,3.2vw,2.5rem);letter-spacing:-0.015em;margin:8px 0 12px">Talk to an engineer, not a sales line.</h2>
    <p class="lead">Tell us what you are trying to move off paper or off cash. An engineer calls you back within one working day.</p>
    <form id="f" novalidate>
      <label>Your name<input id="name" required autocomplete="name"></label>
      <label>Organisation<input id="org" required autocomplete="organization"></label>
      <label>Phone<input id="ph" required inputmode="tel" class="mono" placeholder="097 000 0000"></label>
      <label>What do you want to fix?<textarea id="msg" rows="4" placeholder="e.g. Loan collections at 6 branches are still in cash."></textarea></label>
      <div><button class="btn btn-primary" type="submit">Request a call</button></div>
      <div class="ok" id="ok">Thanks. An engineer will call you within one working day.</div>
    </form>
  </div>
  <div class="direct">
    <div><span class="eyebrow">Dial</span><span class="v mono">*388#</span></div>
    <div><span class="eyebrow">Phone</span><span class="v">+260 211 000 000</span></div>
    <div><span class="eyebrow">Email</span><span class="v">hello@ontech.co.zm</span></div>
    <div><span class="eyebrow">Office</span><span class="v">Cairo Road, Lusaka</span><span style="color:var(--on-fg-muted);font-size:0.875rem">Monday to Friday, 07:00 to 19:00</span></div>
  </div>
</div></section>

<footer class="site">
  <div class="wrap">
    <div>{svg("ontech-boxed-primary")}<p style="margin:0;max-width:28em">Ontech Solutions Ltd. Business systems for Zambia, built and supported from Lusaka.</p></div>
    <div><h4>Services</h4><ul><li><a href="#services">ONTECH CRM</a></li><li><a href="#services">ONTECH Connect</a></li><li><a href="#services">ONTECH Guard</a></li><li><a href="#services">ONTECH Cloud</a></li><li><a href="#services">ONTECH BPO</a></li><li><a href="#services">ONTECH Rent</a></li></ul></div>
    <div><h4>Company</h4><ul><li><a href="#case">Customers</a></li><li><a href="#contact">Careers</a></li><li><a href="#contact">Support</a></li><li><a href="#contact">Status</a></li></ul></div>
    <div><h4>Contact</h4><ul><li>+260 211 000 000</li><li>hello@ontech.co.zm</li><li class="mono" style="color:var(--on-signal-dark);font-weight:600">*388#</li></ul></div>
  </div>
  <div class="wrap legal"><span>© 2026 Ontech Solutions Ltd · Lusaka, Zambia</span><span>Privacy · Terms · PCI-DSS hosted in Lusaka</span></div>
</footer>
<script>
document.getElementById('f').addEventListener('submit', function(e) {{
  e.preventDefault();
  var ok = true; ['name','org','ph'].forEach(function(id) {{ var el = document.getElementById(id); var bad = !el.value.trim(); el.style.borderColor = bad ? 'var(--on-error-text-role)' : ''; if (bad) ok = false; }});
  if (ok) {{ document.getElementById('ok').classList.add('show'); }}
}});
</script>
"""
os.makedirs(os.path.join(ROOT, "site"), exist_ok=True)
open(os.path.join(ROOT, "site", "index.html"), "w").write(html)
print(len(html))
