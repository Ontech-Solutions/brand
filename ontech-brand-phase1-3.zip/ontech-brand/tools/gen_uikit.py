import os, base64
ROOT = os.path.join(os.path.dirname(__file__), "out", "ontech-brand")
tokens_css = open(os.path.join(ROOT, "tokens", "tokens.css")).read()
ui_css = open(os.path.join(ROOT, "ui-kit", "ontech-ui.css")).read()
logo_dark = open(os.path.join(ROOT, "logo", "svg", "ontech-box-on-dark.svg")).read().replace('width="523" height="146"', '', 1).replace("<svg ", '<svg class="on-logo" ', 1)
import re

rows = [
    ("LN-04471", "Mercy Banda", "Kitwe", "1,200.00", "27 Sep", "success", "Paid *388#"),
    ("LN-04398", "Joseph Phiri", "Kitwe", "850.00", "27 Sep", "success", "Paid *388#"),
    ("LN-04512", "Agnes Tembo", "Ndola", "2,400.00", "27 Sep", "warning", "Due today"),
    ("LN-04120", "Patrick Mwale", "Ndola", "600.00", "25 Sep", "error", "Failed, retry"),
    ("LN-04533", "Ruth Chilufya", "Kitwe", "1,500.00", "28 Sep", "info", "Reminder sent"),
    ("LN-04277", "Boyd Sakala", "Kitwe", "300.00", "22 Sep", "error", "Overdue 5 d"),
]
trs = "".join(f'<tr><td class="on-ref">{r[0]}</td><td>{r[1]}</td><td class="on-muted">{r[2]}</td><td class="num">K {r[3]}</td><td class="on-muted">{r[4]}</td><td><span class="on-pill on-pill-{r[5]}">{r[6]}</span></td><td class="on-row-actions"><button class="on-btn on-btn-quiet on-btn-sm" type="button">Remind</button></td></tr>' for r in rows)

html = f"""<title>ONTECH UI Kit</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600&family=JetBrains+Mono:wght@500;600&display=swap">
<style>
{tokens_css}
{ui_css}
body {{ margin: 0; background: var(--on-bg); color: var(--on-fg); }}
.kit-note {{ background: var(--on-bg-subtle); border-bottom: 1px solid var(--on-border); padding: 10px 16px; font: 500 0.8125rem var(--on-font-ui); display: flex; gap: 16px; align-items: center; justify-content: space-between; flex-wrap: wrap; color: var(--on-fg-muted); }}
.kit-note b {{ color: var(--on-fg); }}
.kit-section {{ padding: var(--on-space-7) var(--on-space-7) 0; display: flex; flex-direction: column; gap: var(--on-space-5); }}
.kit-section h2 {{ font-size: var(--on-text-h2); font-weight: 600; margin: 0; letter-spacing: -0.01em; }}
.kit-row {{ display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }}
.kit-swatch {{ height: 40px; flex: 1; min-width: 40px; display: flex; align-items: flex-end; padding: 4px 6px; font: 500 0.6875rem var(--on-font-mono); color: #111; }}
@media (max-width: 900px) {{ .kit-section {{ padding: var(--on-space-5) var(--on-space-4) 0; }} }}
</style>
<div class="kit-note"><span><b>ONTECH UI kit v1</b> · tokens.css + ontech-ui.css, no framework · light and dark follow the system</span><span><button class="on-btn on-btn-ghost on-btn-sm" id="theme" type="button">Toggle dark</button></span></div>

<div class="on-app on-shell">
  <aside class="on-sidebar">
    {logo_dark}
    <nav class="on-nav" aria-label="Main">
      <a href="#" aria-current="page">Collections</a><a href="#">Borrowers</a><a href="#">Loans</a><a href="#">Agents</a><a href="#">Branches</a><a href="#">Messages</a><a href="#">Reports</a><a href="#">Settings</a>
    </nav>
    <div style="margin-top:auto;font-size:0.75rem;color:var(--on-neutral-400)">Kwacha Microfinance<br>Kitwe branch · <span class="on-mono" style="color:var(--on-signal-dark)">*388#</span> live</div>
  </aside>
  <main class="on-main">
    <div class="on-topbar">
      <div>
        <div class="on-crumbs"><a href="#">Kwacha MFI</a><span>/</span><a href="#">Kitwe</a><span>/</span><span>Collections</span></div>
        <h1 class="on-h1" style="margin-top:4px">Collections</h1>
      </div>
      <div class="kit-row">
        <span class="on-pill on-pill-live">USSD live</span>
        <button class="on-btn on-btn-ghost" type="button">Export</button>
        <button class="on-btn on-btn-primary" type="button">Send reminders</button>
      </div>
    </div>

    <div class="on-grid on-grid-4">
      <div class="on-card on-stat"><span class="on-label">Collected this week</span><span class="on-stat-value">K 2.41m</span><span class="on-stat-delta up">▲ 31% vs last week</span></div>
      <div class="on-card on-stat"><span class="on-label">Paid via *388#</span><span class="on-stat-value">92%</span><span class="on-stat-delta up">▲ 4 pts</span></div>
      <div class="on-card on-stat"><span class="on-label">Due today</span><span class="on-stat-value">88</span><span class="on-stat-delta on-muted">K 104,300</span></div>
      <div class="on-card on-stat"><span class="on-label">Failed payments</span><span class="on-stat-value">14</span><span class="on-stat-delta down">▼ needs a call</span></div>
    </div>

    <div class="on-alert on-alert-warning"><span>⚠</span><div><strong>Airtel Money is slow since 09:10.</strong> Payments are queuing and will post automatically. Borrowers still get an SMS receipt.</div></div>

    <div class="on-card">
      <div class="on-card-head"><h2 class="on-h3">Today's payments</h2><div class="on-tabs"><button type="button" aria-selected="true">All</button><button type="button">Paid</button><button type="button">Due</button><button type="button">Failed</button></div></div>
      <div class="on-table-wrap"><table class="on-table">
        <thead><tr><th>Loan</th><th>Borrower</th><th>Branch</th><th class="num">Amount</th><th>Due</th><th>Status</th><th></th></tr></thead>
        <tbody>{trs}</tbody>
      </table></div>
      <div class="on-pagination"><span>1–6 of 1,204</span><button class="on-btn on-btn-quiet on-btn-sm" type="button">‹</button><button class="on-btn on-btn-quiet on-btn-sm" type="button">›</button></div>
    </div>

    <div class="on-grid on-grid-2">
      <div class="on-card">
        <h2 class="on-h3">Record a cash payment</h2>
        <div class="on-field"><label for="loan">Loan number</label><input class="on-input on-mono" id="loan" value="LN-04120"><span class="on-hint">Type the number or scan the card.</span></div>
        <div class="on-field"><label for="amt">Amount</label><div class="on-input-group"><span class="on-prefix">ZMW</span><input class="on-input on-mono" id="amt" value="600.00" inputmode="decimal"></div></div>
        <div class="on-field"><label for="agent">Collected by</label><select class="on-select" id="agent"><option>Chanda Mulenga (agent 14)</option><option>Grace Lungu (agent 09)</option></select></div>
        <div class="on-field"><label for="phone">Borrower phone</label><input class="on-input on-mono" id="phone" value="097 123 456" aria-invalid="true"><span class="on-error-msg">Number needs 10 digits. Check the last digit.</span></div>
        <label class="on-check"><input type="checkbox" checked> Send SMS receipt</label>
        <div class="kit-row"><button class="on-btn on-btn-primary" type="button">Post payment</button><button class="on-btn on-btn-quiet" type="button">Cancel</button></div>
      </div>
      <div class="on-card">
        <h2 class="on-h3">What the borrower sees</h2>
        <p class="on-small on-muted" style="margin:0">USSD screens, under 160 characters, numbered, one action per line.</p>
        <div class="on-ussd">ONTECH  *388#
Kwacha MFI
1. Check balance
2. Pay loan
3. Talk to us
0. Back</div>
        <div class="on-ussd">Pay loan LN-04471
Balance K 3,600.00
Due 30 Sep
1. Pay K 1,200 (this month)
2. Other amount
0. Back</div>
        <div class="on-alert on-alert-success"><span>✓</span><div><strong>Paid. K 1,200.00 posted to LN-04471.</strong> Receipt SMS sent to 097 *** 456. Ref TXN-0093-4471.</div></div>
        <div class="kit-row"><span class="on-tag">SMS EN</span><span class="on-tag">SMS BEM</span><span class="on-tag">SMS NYA</span><button class="on-toggle" role="switch" aria-checked="true" aria-label="Reminders on" type="button"></button><span class="on-small">Reminders 2 days before due</span></div>
      </div>
    </div>
  </main>
</div>

<div class="kit-section on-app">
  <h2>Every component</h2>
  <div class="kit-row"><button class="on-btn on-btn-primary" type="button">Primary</button><button class="on-btn on-btn-ink" type="button">Ink</button><button class="on-btn on-btn-ghost" type="button">Ghost</button><button class="on-btn on-btn-quiet" type="button">Quiet</button><button class="on-btn on-btn-danger" type="button">Delete</button><button class="on-btn on-btn-primary" type="button" disabled>Disabled</button><button class="on-btn on-btn-primary on-btn-sm" type="button">Small</button><button class="on-btn on-btn-primary on-btn-lg" type="button">Large</button></div>
  <div class="kit-row"><span class="on-pill on-pill-success">Paid</span><span class="on-pill on-pill-warning">Due today</span><span class="on-pill on-pill-error">Failed</span><span class="on-pill on-pill-info">Reminder sent</span><span class="on-pill on-pill-neutral">Closed</span><span class="on-pill on-pill-live">USSD live</span><span class="on-tag">Tag</span></div>
  <div class="on-grid on-grid-2">
    <div class="on-alert on-alert-info"><span>i</span><div><strong>Month-end closes tonight at 23:00.</strong> Anything posted after that lands in October.</div></div>
    <div class="on-alert on-alert-error"><span>✕</span><div><strong>Payment not sent.</strong> Check the phone number and try again.</div></div>
  </div>
  <div class="on-empty"><strong>No failed payments</strong><span class="on-small">Everything due today has posted. Come back after 17:00 for the evening batch.</span><button class="on-btn on-btn-ghost on-btn-sm" type="button">View all payments</button></div>
  <div class="on-grid on-grid-3"><div class="on-skeleton" style="height:18px"></div><div class="on-skeleton" style="height:18px;width:60%"></div><div class="on-skeleton" style="height:18px;width:80%"></div></div>
  <div><span class="on-label">Chart series order</span><div class="kit-row" style="margin-top:8px">{''.join(f'<div class="kit-swatch" style="background:var(--on-chart-{i})">{i}</div>' for i in range(1,9))}</div></div>
  <p class="on-small on-muted" style="margin:0 0 48px">Files: <code>ui-kit/ontech-ui.css</code>, <code>ui-kit/tailwind.preset.js</code>, <code>ui-kit/README.md</code>. Load <code>tokens/tokens.css</code> first.</p>
</div>
<script>
(function(){{
  var b=document.getElementById('theme'); if(!b) return;
  b.addEventListener('click',function(){{
    var r=document.documentElement, cur=r.getAttribute('data-theme');
    var sys=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;
    var isDark=cur==='dark'||(cur!=='light'&&sys);
    r.setAttribute('data-theme', isDark?'light':'dark');
  }});
}})();
</script>
"""
open(os.path.join(ROOT, "ui-kit", "index.html"), "w").write(html)

# Tailwind preset from tokens.json
import json
t = json.load(open(os.path.join(ROOT, "tokens", "tokens.json")))
N = t["color"]["neutral"]; S = t["color"]["signal"]; SEM = t["color"]["semantic"]
colors = {"ink": N["ink"], "paper": N["paper"], "neutral": {k: v for k, v in N.items() if k not in ("ink", "paper")}, "signal": {"DEFAULT": S["signal"], "strong": S["signal-strong"], "soft": S["signal-soft"], "dark": S["signal-dark"]}}
for k, v in SEM.items(): colors[k] = {"text": v["text"], "DEFAULT": v["fill"], "soft": v["soft"], "dark": v["dark-text"], "darksoft": v["dark-soft"]}
colors["chart"] = {str(i + 1): c for i, c in enumerate(t["color"]["chart"])}
fs = {k: [f"{v['px']/16:g}rem", {"lineHeight": str(v["line"]), "letterSpacing": v["tracking"], "fontWeight": str(v["weight"])}] for k, v in t["type"]["size"].items()}
preset = {"theme": {"extend": {
    "colors": colors,
    "fontFamily": {"sans": ["Jost", "system-ui", "sans-serif"], "mono": ["JetBrains Mono", "ui-monospace", "monospace"]},
    "fontSize": fs,
    "spacing": {k: f"{v}px" for k, v in t["space"].items()},
    "borderRadius": {k: f"{v}px" for k, v in t["radius"].items()},
    "transitionDuration": {k: f"{v}ms" for k, v in t["motion"].items() if isinstance(v, int)},
}}}
open(os.path.join(ROOT, "ui-kit", "tailwind.preset.js"), "w").write("// ONTECH Tailwind preset — generated from tokens/tokens.json\nmodule.exports = " + json.dumps(preset, indent=2) + ";\n")
open(os.path.join(ROOT, "ui-kit", "README.md"), "w").write("""# ONTECH UI kit

Framework-agnostic. Two stylesheets, in this order:

    <link rel="stylesheet" href="tokens/tokens.css">
    <link rel="stylesheet" href="ui-kit/ontech-ui.css">

Wrap the app in `.on-app`. Classes are prefixed `on-`; see `index.html` for every component in a
working Collections screen, in light and dark (toggle top right, or follow the system).

Tailwind users: `presets: [require('./ui-kit/tailwind.preset.js')]` gives the same colours,
type scale, spacing and radii as utilities (`bg-signal`, `text-success-text`, `font-mono`, `text-h1`).

React / Blazor / PHP: use the classes directly, or wrap them in components. The kit has no JavaScript
except the theme toggle on the demo page. Modals use the native `<dialog>` element with `.on-modal`.

Rules that matter in product UI:

1. One primary button per view. It is amber with an ink border on light, amber without a border on dark.
2. Status is a pill with a dot, never colour on the text alone. Success, warning, error, info, neutral, live.
3. Anything a person dials, pays or copies is in the mono face with tabular figures: loan numbers, amounts, references, phone numbers.
4. Error messages say what happened and what to do: "Payment not sent. Check the phone number and try again."
5. Dark mode comes from the tokens; do not hard-code colours in components.
""")
print("ok")
