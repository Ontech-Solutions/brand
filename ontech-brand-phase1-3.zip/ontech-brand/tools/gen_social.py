"""Social post templates + WhatsApp status + email signature, generated as SVG -> PNG from the tokens.
Each template is a function of (headline, kicker, ...) so the team can regenerate with real content."""
import os, io, json, base64, cairosvg
from PIL import Image
from gen_logo import text_path, FONT_M, FONT_SB, FONT_MONO, f
import gen_logo

ROOT = os.path.join(os.path.dirname(__file__), "out", "ontech-brand")
SVG = os.path.join(ROOT, "logo", "svg")
OUT = os.path.join(ROOT, "templates", "social")
os.makedirs(OUT, exist_ok=True)
INK, PAPER, SIGNAL, SIGNAL_DARK, N400, N600, N100, STRONG = "#111111", "#FFFFFF", "#F5A524", "#FFB84D", "#B3ACA4", "#6E6861", "#F4F1EC", "#945600"
FONT_R = os.path.join(os.path.dirname(__file__), "fonts", "Jost-400.ttf")

def inner_svg(name):
    s = open(os.path.join(SVG, name + ".svg")).read()
    body = s.split(">", 1)[1].rsplit("</svg>", 1)[0]
    vb = s.split('viewBox="')[1].split('"')[0].split()
    return body, float(vb[2]), float(vb[3])

def logo(name, x, y, w):
    body, vw, vh = inner_svg(name)
    sc = w / vw
    return f'<g transform="translate({f(x)},{f(y)}) scale({f(sc)})">{body}</g>'

def txt(s, x, y, size, font=FONT_SB, fill=INK, tracking=0.0, anchor="start"):
    d, w = text_path(s, font, size, tracking)
    dx = {"start": 0, "middle": -w / 2, "end": -w}[anchor]
    return f'<path fill="{fill}" transform="translate({f(x + dx)},{f(y)})" d="{d}"/>', w

def wrap(s, font, size, max_w, tracking=0.0):
    words = s.split(); lines = []; cur = ""
    for wd in words:
        t = (cur + " " + wd).strip()
        if text_path(t, font, size, tracking)[1] > max_w and cur:
            lines.append(cur); cur = wd
        else: cur = t
    if cur: lines.append(cur)
    return lines

def block(lines, x, y, size, font, fill, lh=1.12, anchor="start"):
    out = []
    for i, ln in enumerate(lines):
        out.append(txt(ln, x, y + i * size * lh, size, font, fill, anchor=anchor)[0])
    return "".join(out), y + (len(lines) - 1) * size * lh

def save(name, W, H, body):
    s = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">{body}</svg>'
    open(os.path.join(OUT, name + ".svg"), "w").write(s)
    cairosvg.svg2png(bytestring=s.encode(), write_to=os.path.join(OUT, name + ".png"), output_width=W)

# ---------- 1. Statement post (dark) 1080x1080 ----------
def post_statement(headline, source, name="01-statement-dark"):
    W = H = 1080; m = 88
    b = f'<rect width="{W}" height="{H}" fill="{INK}"/>'
    b += logo("ontech-boxed", m, m, 300)
    lines = wrap(headline, FONT_SB, 78, W - 2 * m)
    t, yend = block(lines, m, 440, 78, FONT_SB, PAPER, 1.1)
    b += t
    b += f'<rect x="{m}" y="{yend + 50}" width="80" height="10" fill="{SIGNAL}"/>'
    b += txt(source, m, yend + 110, 26, FONT_R, N400)[0]
    b += txt("*388#", W - m, H - m, 40, FONT_MONO, SIGNAL_DARK, anchor="end")[0]
    save(name, W, H, b)

# ---------- 2. Stat post (light) ----------
def post_stat(number, what, context, name="02-stat-light"):
    W = H = 1080; m = 88
    b = f'<rect width="{W}" height="{H}" fill="{PAPER}"/>'
    b += logo("ontech-wordmark-on-light", m, m, 260)
    b += txt(number, m, 600, 260, FONT_SB, INK)[0]
    b += txt(what, m, 690, 54, FONT_SB, INK)[0]
    t, _ = block(wrap(context, FONT_R, 30, W - 2 * m), m, 760, 30, FONT_R, N600, 1.35)
    b += t
    b += f'<rect x="{m}" y="{H - m - 10}" width="{W - 2*m}" height="2" fill="{INK}"/>'
    b += txt("CONNECT.  AUTOMATE.  ACCELERATE.", m, H - m - 30, 20, FONT_M, N600, tracking=0.18)[0]
    b += txt("*388#", W - m, H - m - 30, 24, FONT_MONO, STRONG, anchor="end")[0]
    save(name, W, H, b)

# ---------- 3. Quote post (dark) ----------
def post_quote(quote, who, name="03-quote-dark"):
    W = H = 1080; m = 88
    b = f'<rect width="{W}" height="{H}" fill="{INK}"/>'
    b += txt("“", m - 10, 330, 220, FONT_SB, SIGNAL_DARK)[0]
    t, yend = block(wrap(quote, FONT_M, 54, W - 2 * m), m, 430, 54, FONT_M, PAPER, 1.25)
    b += t
    b += txt(who, m, yend + 90, 28, FONT_R, N400)[0]
    b += logo("ontech-boxed", m, H - m - 100, 300)
    save(name, W, H, b)

# ---------- 4. Announcement (light, USSD screen) ----------
def post_announce(headline, ussd_lines, name="04-announce-light"):
    W = H = 1080; m = 88
    b = f'<rect width="{W}" height="{H}" fill="{PAPER}"/>'
    b += logo("ontech-wordmark-on-light", m, m, 260)
    t, _ = block(wrap(headline, FONT_SB, 60, 520), m, 330, 60, FONT_SB, INK, 1.1)
    b += t
    # phone panel
    px, py, pw, ph = 660, 240, 332, 620
    b += f'<rect x="{px}" y="{py}" width="{pw}" height="{ph}" rx="28" fill="{INK}"/>'
    b += f'<rect x="{px+18}" y="{py+60}" width="{pw-36}" height="{ph-120}" fill="{N100}"/>'
    for i, ln in enumerate(ussd_lines):
        b += txt(ln, px + 40, py + 120 + i * 44, 24, FONT_MONO, INK)[0]
    b += f'<rect x="{px+18}" y="{py+ph-52}" width="{pw-36}" height="6" fill="{SIGNAL}"/>'
    b += txt("Dial", m, H - m - 40, 30, FONT_R, N600)[0]
    b += txt("*388#", m + 70, H - m - 40, 44, FONT_MONO, INK)[0]
    save(name, W, H, b)

# ---------- 5. Event / date (dark, big date) ----------
def post_event(kicker, title, date, place, name="05-event-dark"):
    W = H = 1080; m = 88
    b = f'<rect width="{W}" height="{H}" fill="{INK}"/>'
    b += txt(kicker.upper(), m, m + 20, 24, FONT_M, N400, tracking=0.18)[0]
    b += txt(date, m, 400, 170, FONT_SB, SIGNAL_DARK)[0]
    t, yend = block(wrap(title, FONT_SB, 60, W - 2 * m), m, 500, 60, FONT_SB, PAPER, 1.1)
    b += t
    b += txt(place, m, yend + 80, 30, FONT_R, N400)[0]
    b += logo("ontech-boxed", m, H - m - 100, 300)
    save(name, W, H, b)

# ---------- 6. Hiring / plain text (light, framed) ----------
def post_frame(kicker, title, body, name="06-frame-light"):
    W = H = 1080; m = 60
    b = f'<rect width="{W}" height="{H}" fill="{INK}"/><rect x="{m}" y="{m}" width="{W-2*m}" height="{H-2*m}" fill="{PAPER}"/>'
    im = m + 70
    b += txt(kicker.upper(), im, im + 10, 24, FONT_M, STRONG, tracking=0.18)[0]
    t, yend = block(wrap(title, FONT_SB, 72, W - 2 * im), im, im + 130, 72, FONT_SB, INK, 1.08)
    b += t
    t2, _ = block(wrap(body, FONT_R, 32, W - 2 * im), im, yend + 110, 32, FONT_R, N600, 1.35)
    b += t2
    b += logo("ontech-wordmark-on-light", im, H - im - 60, 240)
    b += txt("ontech.co.zm", W - im, H - im - 20, 28, FONT_M, INK, anchor="end")[0]
    save(name, W, H, b)

# ---------- WhatsApp status 1080x1920 ----------
def status(headline, sub, name="07-whatsapp-status"):
    W, H = 1080, 1920; m = 96
    b = f'<rect width="{W}" height="{H}" fill="{INK}"/>'
    b += logo("ontech-boxed", m, 200, 340)
    t, yend = block(wrap(headline, FONT_SB, 92, W - 2 * m), m, 820, 92, FONT_SB, PAPER, 1.08)
    b += t
    b += f'<rect x="{m}" y="{yend + 60}" width="90" height="12" fill="{SIGNAL}"/>'
    t2, _ = block(wrap(sub, FONT_R, 38, W - 2 * m), m, yend + 150, 38, FONT_R, N400, 1.35)
    b += t2
    b += txt("Dial", m, H - 260, 36, FONT_R, N400)[0]
    b += txt("*388#", m + 90, H - 260, 72, FONT_MONO, SIGNAL_DARK)[0]
    b += txt("CONNECT.  AUTOMATE.  ACCELERATE.", m, H - 160, 24, FONT_M, N400, tracking=0.18)[0]
    save(name, W, H, b)

# ---------- Profile + banners regenerated on the new masters ----------
def banners():
    for name, W, H, safe_l in [("linkedin-banner-1584x396", 1584, 396, 330), ("x-header-1500x500", 1500, 500, 380), ("facebook-cover-1640x624", 1640, 624, 0)]:
        b = f'<rect width="{W}" height="{H}" fill="{INK}"/>'
        lw = min(520, W * 0.34)
        x = safe_l + (W - safe_l - lw) / 2 if safe_l else W * 0.08
        b += logo("ontech-boxed", x, H / 2 - lw * (191 / 566) / 2 - 20, lw)
        b += txt("Business systems that run on any phone in Zambia.", x, H / 2 + lw * (191 / 566) / 2 + 40, 26, FONT_R, N400)[0]
        b += txt("*388#", W - 60, H - 40, 34, FONT_MONO, SIGNAL_DARK, anchor="end")[0]
        save(name, W, H, b)
    # profile picture: icon on ink
    b = f'<rect width="1080" height="1080" fill="{INK}"/>' + logo("ontech-icon", 140, 140, 800)
    save("profile-icon-1080", 1080, 1080, b)

# ---------- Email signature (HTML, table-based, inline styles) ----------
def signature():
    png = open(os.path.join(ROOT, "logo", "png", "ontech-boxed-600.png"), "rb").read()
    data = "data:image/png;base64," + base64.b64encode(png).decode()
    html = f"""<!-- ONTECH email signature. Replace NAME, TITLE, PHONE, EMAIL. Logo is embedded; swap src for a hosted https URL if your mail client strips data URIs. -->
<table cellpadding="0" cellspacing="0" border="0" style="font-family:Jost,Arial,Helvetica,sans-serif;font-size:14px;line-height:1.4;color:#111111;border-collapse:collapse">
  <tr>
    <td style="padding:0 18px 0 0;vertical-align:top;border-right:2px solid #111111"><img src="{data}" width="132" height="45" alt="ONTECH" style="display:block;border:0"></td>
    <td style="padding:0 0 0 18px;vertical-align:top">
      <div style="font-weight:600;font-size:16px">Dennis Zitha</div>
      <div style="color:#6E6861">Director, Ontech Solutions Ltd</div>
      <div style="padding-top:8px"><a href="tel:+260970000000" style="color:#111111;text-decoration:none">+260 97 000 0000</a> &nbsp;·&nbsp; <a href="mailto:dennis@ontech.co.zm" style="color:#111111;text-decoration:none">dennis@ontech.co.zm</a></div>
      <div><a href="https://ontech.co.zm" style="color:#111111;text-decoration:none">ontech.co.zm</a> &nbsp;·&nbsp; <span style="font-family:'JetBrains Mono',Menlo,Consolas,monospace;color:#945600;font-weight:600">*388#</span></div>
    </td>
  </tr>
  <tr><td colspan="2" style="padding-top:12px;font-size:11px;letter-spacing:0.14em;color:#6E6861">CONNECT. &nbsp;AUTOMATE. &nbsp;ACCELERATE.</td></tr>
</table>"""
    d = os.path.join(ROOT, "templates", "email"); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "signature.html"), "w").write(html)
    # rendered preview
    cairosvg.svg2png(url=os.path.join(SVG, "ontech-boxed.svg"), output_width=264, write_to=os.path.join(d, "signature-logo-264.png"))
    open(os.path.join(d, "signature-preview.html"), "w").write("<title>Signature preview</title><body style='padding:40px;background:#fff'>" + html)

if __name__ == "__main__":
    post_statement("Your agents spend 3 of every 5 hours travelling to collect cash.", "Agent timesheets, Kitwe and Ndola, August 2026")
    post_stat("31%", "more collected per agent", "Median across the first 12 MFIs live on *388# for six months or more, January to August 2026.")
    post_quote("The agents did not believe it until the first Friday. Then nobody wanted to go back to the motorbike.", "Operations manager, Copperbelt MFI")
    post_announce("Pay your loan from any phone. No app, no data.", ["ONTECH  *388#", "1. Check balance", "2. Pay loan", "3. Talk to us", "0. Back"])
    post_event("Free workshop for MFIs", "Moving collections off cash", "14 Oct", "Radisson Blu, Lusaka · 09:00 to 12:00 · 30 seats")
    post_frame("We are hiring", "Support engineer, Lusaka", "You answer the phone when a branch cannot post a payment, and you fix it. USSD, SMS gateways, Linux. Apply by 10 October.")
    status("Pay your loan from any phone.", "No app. No data bundle. A receipt by SMS in seconds.")
    banners()
    signature()
    print(sorted(os.listdir(OUT)))
