"""Fails if any USSD screen (``` code block) in guidelines/ussd.md exceeds 160 characters."""
import re, sys, os
p = os.path.join(os.path.dirname(__file__), "..", "guidelines", "ussd.md")
blocks = re.findall(r"```\n(.*?)```", open(p).read(), re.S)
bad = 0
for b in blocks:
    n = len(b.rstrip("\n"))
    flag = "OVER" if n > 160 else "ok"
    if n > 160: bad += 1
    print(f"{n:4d} {flag}  {b.splitlines()[0][:50]}")
sys.exit(1 if bad else 0)
