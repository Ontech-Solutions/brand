// ONTECH sales deck template — 12 layouts on the Phase 1 tokens.
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "out", "ontech-brand");
const PNG = (n) => "image/png;base64," + fs.readFileSync(path.join(ROOT, "logo", "png", n)).toString("base64");
const ICON = (n) => "image/png;base64," + fs.readFileSync(path.join(ROOT, "logo", "icons", n)).toString("base64");

// tokens
const INK = "111111", PAPER = "FFFFFF", SIGNAL = "F5A524", SIGNAL_DARK = "FFB84D", STRONG = "945600";
const N900 = "1F1D1A", N700 = "55504A", N600 = "6E6861", N400 = "B3ACA4", N300 = "D6D0C8", N200 = "E9E5DF", N100 = "F4F1EC";
const SUCCESS = "2FA35A", INFO = "2F7BD1", ERROR = "D93A31";
const F = "Jost", MONO = "JetBrains Mono";

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5
pres.author = "ONTECH"; pres.company = "Ontech Solutions"; pres.title = "ONTECH deck template";
const W = 13.333, H = 7.5, M = 0.6;

const T = (slide, text, o) => slide.addText(text, Object.assign({ isTextBox: true, fontFace: F, margin: 0, color: INK }, o));
const label = (slide, text, x, y, w, color, opts = {}) =>
  T(slide, text.toUpperCase(), Object.assign({ x, y, w, h: 0.3, fontSize: 10, charSpacing: 3, color, bold: false }, opts));

// footer used on light slides: wordmark small left, slide number right
function footer(slide, dark = false, note) {
  slide.addImage({ data: PNG(dark ? "ontech-wordmark-on-dark-600.png" : "ontech-wordmark-on-light-600.png"), x: M, y: H - 0.62, w: 0.85, h: 0.85 * (146 / 423) });
  if (note) T(slide, note, { x: M + 1.1, y: H - 0.6, w: 7, h: 0.3, fontSize: 9, color: dark ? N400 : N600 });
  slide.addText("", { x: W - M - 0.6, y: H - 0.6, w: 0.6, h: 0.3, isTextBox: true, fontFace: MONO, fontSize: 9, color: dark ? N400 : N600, align: "right", margin: 0 });
  slide.slideNumber = { x: W - M - 0.6, y: H - 0.6, w: 0.6, h: 0.3, fontFace: MONO, fontSize: 9, color: dark ? N400 : N600, align: "right" };
}

// ---------- 1. Cover (dark) ----------
{
  const s = pres.addSlide(); s.background = { color: INK };
  s.addImage({ data: PNG("ontech-boxed-2400.png"), x: M, y: 0.7, w: 3.4, h: 3.4 * (190 / 566) });
  T(s, "Collections that reach every borrower, on any phone.", { x: M, y: 3.0, w: 8.6, h: 1.9, fontSize: 40, bold: true, color: PAPER, lineSpacingMultiple: 1.05, valign: "top" });
  T(s, "Proposal for Kwacha Microfinance", { x: M, y: 5.05, w: 8, h: 0.4, fontSize: 18, color: N400 });
  label(s, "27 September 2026  ·  Lusaka  ·  Confidential", M, H - 0.9, 8, N400);
  s.addText("*388#", { x: W - M - 2.2, y: H - 1.0, w: 2.2, h: 0.5, isTextBox: true, fontFace: MONO, fontSize: 22, bold: true, color: SIGNAL_DARK, align: "right", margin: 0 });
  s.addNotes("Cover. Title is the outcome for this customer, not our product name. Keep it under 12 words.");
}
// ---------- 2. Agenda ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "What we will cover", { x: M, y: M, w: 6, h: 0.8, fontSize: 32, bold: true });
  const items = [["Where collections stand today", "Your numbers, from the data you sent us"], ["What changes with *388#", "Agents, borrowers and the branch"], ["The system", "ONTECH CRM, USSD, SMS and the ledger"], ["Rollout in 6 weeks", "Week by week, with what we need from you"], ["Price and terms", "Fixed. No surprises."]];
  items.forEach((it, i) => {
    const y = 1.7 + i * 0.98;
    s.addText(String(i + 1).padStart(2, "0"), { x: M, y, w: 0.7, h: 0.5, isTextBox: true, fontFace: MONO, fontSize: 14, color: STRONG, margin: 0 });
    T(s, it[0], { x: M + 0.8, y, w: 7, h: 0.45, fontSize: 20, bold: true });
    T(s, it[1], { x: M + 0.8, y: y + 0.42, w: 7, h: 0.35, fontSize: 13, color: N600 });
    if (i < items.length - 1) s.addShape(pres.ShapeType.line, { x: M + 0.8, y: y + 0.88, w: 7.6, h: 0, line: { color: N200, width: 0.75 } });
  });
  s.addShape(pres.ShapeType.rect, { x: 9.4, y: 1.7, w: 3.33, h: 4.6, fill: { color: N100 }, line: { color: N100 } });
  s.addImage({ data: ICON("ontech-icon-1024.png"), x: 10.4, y: 3.2, w: 1.35, h: 1.35 });
  footer(s);
  s.addNotes("Agenda. Five items maximum. The right panel can hold a photo of the customer's branch or team instead of the icon.");
}
// ---------- 3. Section divider (dark) ----------
{
  const s = pres.addSlide(); s.background = { color: INK };
  s.addText("01", { x: M, y: 2.2, w: 3, h: 1, isTextBox: true, fontFace: MONO, fontSize: 48, color: SIGNAL_DARK, margin: 0 });
  T(s, "Where collections stand today", { x: M, y: 3.2, w: 9, h: 1.2, fontSize: 40, bold: true, color: PAPER });
  T(s, "Your numbers, from the data you sent us on 19 September.", { x: M, y: 4.4, w: 9, h: 0.5, fontSize: 18, color: N400 });
  footer(s, true);
  s.addNotes("Section divider. Number in mono, title in Jost. One line of context under it, never a paragraph.");
}
// ---------- 4. Statement (one big line) ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "Your agents spend 3 of every 5 working hours travelling to collect cash.", { x: M, y: 1.5, w: 10.5, h: 2.6, fontSize: 44, bold: true, lineSpacingMultiple: 1.05, valign: "top" });
  T(s, "Source: agent timesheets, Kitwe and Ndola branches, August 2026. 41 agents, 2,120 visits.", { x: M, y: 4.6, w: 10, h: 0.4, fontSize: 13, color: N600 });
  s.addShape(pres.ShapeType.rect, { x: M, y: 5.3, w: 1.2, h: 0.14, fill: { color: SIGNAL }, line: { color: SIGNAL } });
  footer(s);
  s.addNotes("Statement. One finding, one source line. The amber mark is the only ornament; use it once per slide at most.");
}
// ---------- 5. Two column: text + image/panel ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "What changes with *388#", { x: M, y: M, w: 7, h: 0.8, fontSize: 32, bold: true });
  const rows = [["Borrower", "Dials *388#, picks the loan, confirms with a PIN. Works on a K150 phone with no data."], ["Agent", "Sees the payment on the CRM before leaving the office. Visits only the 8% who did not pay."], ["Branch", "Ledger updates the same minute. No cash on the road, no end-of-day reconciliation."]];
  rows.forEach((r, i) => {
    const y = 1.75 + i * 1.45;
    T(s, r[0], { x: M, y, w: 5.9, h: 0.4, fontSize: 18, bold: true });
    T(s, r[1], { x: M, y: y + 0.42, w: 5.9, h: 0.9, fontSize: 14, color: N700, lineSpacingMultiple: 1.2, valign: "top" });
  });
  // USSD phone panel
  s.addShape(pres.ShapeType.rect, { x: 7.6, y: 1.75, w: 5.13, h: 4.6, fill: { color: INK }, line: { color: INK } });
  s.addShape(pres.ShapeType.rect, { x: 9.0, y: 2.3, w: 2.33, h: 3.5, fill: { color: N100 }, line: { color: N100 } });
  s.addText("ONTECH *388#\n1. Check balance\n2. Pay loan\n3. Talk to us\n0. Back", { x: 9.15, y: 2.5, w: 2.1, h: 3.1, isTextBox: true, fontFace: MONO, fontSize: 11, color: INK, margin: 0, valign: "top", lineSpacingMultiple: 1.5 });
  footer(s);
  s.addNotes("Two column. Left: three rows of who/what. Right: a panel — USSD screen, screenshot, or photo. Swap the ink panel for an image with the same frame.");
}
// ---------- 6. Three column ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "One system, three parts", { x: M, y: M, w: 8, h: 0.8, fontSize: 32, bold: true });
  const cols = [["CRM", "Loans, borrowers, agents and branches in one place. Built for 5 to 500 loan officers.", "ONTECH CRM"], ["USSD + SMS", "*388# for payments and balances. SMS reminders on the due date, in English, Bemba or Nyanja.", "ONTECH Connect"], ["Ledger", "Every payment posted to your core system or ours within 3 seconds. Reconciled nightly.", "ONTECH Pay"]];
  const cw = (W - 2 * M - 0.5) / 3;
  cols.forEach((c, i) => {
    const x = M + i * (cw + 0.25);
    s.addShape(pres.ShapeType.rect, { x, y: 1.75, w: cw, h: 4.4, fill: { color: N100 }, line: { color: N100 } });
    s.addShape(pres.ShapeType.rect, { x: x + 0.35, y: 2.15, w: 0.5, h: 0.5, fill: { color: INK }, line: { color: INK } });
    s.addText(String(i + 1), { x: x + 0.35, y: 2.15, w: 0.5, h: 0.5, isTextBox: true, fontFace: MONO, fontSize: 14, bold: true, color: SIGNAL, align: "center", valign: "middle", margin: 0 });
    T(s, c[0], { x: x + 0.35, y: 2.9, w: cw - 0.7, h: 0.5, fontSize: 22, bold: true });
    T(s, c[1], { x: x + 0.35, y: 3.45, w: cw - 0.7, h: 1.8, fontSize: 13, color: N700, lineSpacingMultiple: 1.25, valign: "top" });
    label(s, c[2], x + 0.35, 5.6, cw - 0.7, STRONG);
  });
  footer(s);
  s.addNotes("Three column. Product names are ONTECH + descriptor in the label row. Never add product logos.");
}
// ---------- 7. Stat row (dark) ----------
{
  const s = pres.addSlide(); s.background = { color: INK };
  T(s, "What the first 12 MFIs saw", { x: M, y: M, w: 9, h: 0.8, fontSize: 32, bold: true, color: PAPER });
  T(s, "Median across customers live for 6 months or more, Jan to Aug 2026.", { x: M, y: 1.35, w: 9, h: 0.4, fontSize: 14, color: N400 });
  const stats = [["31%", "more collected", "per agent per month"], ["3 s", "to post", "USSD payment to ledger"], ["62%", "fewer visits", "agents on the road"], ["6 wk", "to go live", "median, signed to first payment"]];
  const cw = (W - 2 * M - 0.9) / 4;
  stats.forEach((st, i) => {
    const x = M + i * (cw + 0.3);
    s.addShape(pres.ShapeType.line, { x, y: 2.5, w: cw, h: 0, line: { color: N700, width: 0.75 } });
    T(s, st[0], { x, y: 2.7, w: cw, h: 1.2, fontSize: 60, bold: true, color: i === 0 ? SIGNAL_DARK : PAPER });
    T(s, st[1], { x, y: 3.95, w: cw, h: 0.4, fontSize: 18, bold: true, color: PAPER });
    T(s, st[2], { x, y: 4.35, w: cw, h: 0.4, fontSize: 13, color: N400 });
  });
  footer(s, true);
  s.addNotes("Stat row. Four numbers maximum. The first stat is the one that matters and takes the signal colour; the rest stay paper.");
}
// ---------- 8. Chart ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "Collections per agent, before and after *388#", { x: M, y: M, w: 10, h: 0.8, fontSize: 32, bold: true });
  T(s, "K thousand per agent per month, Kwacha Microfinance pilot, Kitwe branch", { x: M, y: 1.35, w: 10, h: 0.4, fontSize: 14, color: N600 });
  s.addChart(pres.ChartType.bar, [
    { name: "Before", labels: ["Mar", "Apr", "May", "Jun", "Jul", "Aug"], values: [38, 41, 39, 40, 42, 41] },
    { name: "With *388#", labels: ["Mar", "Apr", "May", "Jun", "Jul", "Aug"], values: [0, 0, 44, 51, 55, 58] },
  ], {
    x: M, y: 1.9, w: 8.4, h: 4.5, barDir: "col", barGrouping: "clustered", barGapWidthPct: 60,
    chartColors: [N300, SIGNAL], showLegend: true, legendPos: "b", legendFontFace: F, legendFontSize: 11, legendColor: N600,
    showValue: true, dataLabelPosition: "outEnd", dataLabelFontFace: MONO, dataLabelFontSize: 9, dataLabelColor: N700,
    catAxisLabelFontFace: F, catAxisLabelFontSize: 11, catAxisLabelColor: N600, catGridLine: { style: "none" },
    valAxisLabelFontFace: MONO, valAxisLabelFontSize: 9, valAxisLabelColor: N600, valGridLine: { color: N200, size: 0.5 }, valAxisLineShow: false, catAxisLineShow: false,
    valAxisMinVal: 0, valAxisMaxVal: 70,
  });
  s.addShape(pres.ShapeType.rect, { x: 9.4, y: 1.9, w: 3.33, h: 2.6, fill: { color: N100 }, line: { color: N100 } });
  T(s, "58", { x: 9.7, y: 2.1, w: 2.8, h: 0.9, fontSize: 48, bold: true });
  T(s, "K thousand per agent in August, up from 41. The May dip is the two-week training period.", { x: 9.7, y: 3.0, w: 2.8, h: 1.4, fontSize: 12, color: N700, lineSpacingMultiple: 1.2, valign: "top" });
  footer(s, false, "Source: ONTECH CRM ledger export, 1 Sep 2026");
  s.addNotes("Chart. Native chart, two series: neutral grey for the baseline, signal for ours. Side panel carries the one number and the one caveat.");
}
// ---------- 9. Table ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "Rollout in 6 weeks", { x: M, y: M, w: 8, h: 0.8, fontSize: 32, bold: true });
  const hdr = (t) => ({ text: t, options: { bold: true, color: N600, fontSize: 10, fontFace: F, charSpacing: 2, fill: { color: PAPER }, border: [{ type: "none" }, { type: "none" }, { pt: 1, color: INK }, { type: "none" }] } });
  const cell = (t, o = {}) => ({ text: t, options: Object.assign({ fontSize: 12, fontFace: F, color: INK, border: [{ type: "none" }, { type: "none" }, { pt: 0.5, color: N200 }, { type: "none" }], valign: "middle" }, o) });
  const mono = (t) => cell(t, { fontFace: MONO, fontSize: 11, color: STRONG });
  const rows = [
    [hdr("WEEK"), hdr("WHAT HAPPENS"), hdr("WE NEED FROM YOU"), hdr("DONE WHEN")],
    [mono("1"), cell("Kick-off, data import from your spreadsheets"), cell("Loan book export, 2 staff for a day"), cell("Every borrower in the CRM")],
    [mono("2"), cell("USSD menu configured, MTN and Airtel short code linked"), cell("Sign the aggregator form"), cell("*388# answers on a test phone")],
    [mono("3-4"), cell("Agent training, 2 half-days per branch"), cell("Agents present, a room"), cell("Every agent has logged a test payment")],
    [mono("5"), cell("Pilot at Kitwe with live borrowers"), cell("Branch manager on call"), cell("100 real payments posted")],
    [mono("6"), cell("Go-live, all branches, SMS reminders switched on"), cell("Sign-off"), cell("First month-end closed in the CRM")],
  ];
  s.addTable(rows, { x: M, y: 1.7, w: W - 2 * M, colW: [1.0, 4.6, 3.6, 2.93], rowH: [0.4, 0.62, 0.62, 0.62, 0.62, 0.62], margin: [0.06, 0.1, 0.06, 0.1] });
  footer(s);
  s.addNotes("Table. Header row has a single ink rule under it; body rows a hairline. No zebra fills, no vertical lines.");
}
// ---------- 10. Case study ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  s.addShape(pres.ShapeType.rect, { x: 0, y: 0, w: 5.6, h: H, fill: { color: INK }, line: { color: INK } });
  label(s, "Case study  ·  Copperbelt MFI", M, M, 4.4, N400);
  T(s, "14 branches moved off cash in one quarter.", { x: M, y: 1.4, w: 4.4, h: 2.4, fontSize: 30, bold: true, color: PAPER, lineSpacingMultiple: 1.05, valign: "top" });
  T(s, "“The agents did not believe it until the first Friday. Then nobody wanted to go back to the motorbike.”", { x: M, y: 4.2, w: 4.4, h: 1.6, fontSize: 14, italic: true, color: N400, lineSpacingMultiple: 1.25, valign: "top" });
  T(s, "Operations manager, Copperbelt MFI", { x: M, y: 5.9, w: 4.4, h: 0.4, fontSize: 11, color: N400 });
  const facts = [["Before", "K1.6m collected per month, 38 agents, 4 days to reconcile"], ["Change", "*388# payments, SMS reminders 2 days before due, CRM at every branch"], ["After", "K2.3m per month, same agents, reconciled by 09:00 next day"], ["Time", "Signed 3 March, live 14 April 2026"]];
  facts.forEach((fct, i) => {
    const y = M + 0.3 + i * 1.4;
    label(s, fct[0], 6.2, y, 2, STRONG);
    T(s, fct[1], { x: 6.2, y: y + 0.35, w: 6.5, h: 0.9, fontSize: 16, lineSpacingMultiple: 1.2, valign: "top" });
  });
  s.slideNumber = { x: W - M - 0.6, y: H - 0.6, w: 0.6, h: 0.3, fontFace: MONO, fontSize: 9, color: N600, align: "right" };
  s.addNotes("Case study. Left panel is ink and can carry a photo behind the text (set the photo at 40% transparency over ink). Right side: before, change, after, time.");
}
// ---------- 11. Price / terms ----------
{
  const s = pres.addSlide(); s.background = { color: PAPER };
  T(s, "Price and terms", { x: M, y: M, w: 8, h: 0.8, fontSize: 32, bold: true });
  s.addShape(pres.ShapeType.rect, { x: M, y: 1.7, w: 6.0, h: 4.5, fill: { color: N100 }, line: { color: N100 } });
  label(s, "Fixed price, 6-week rollout", M + 0.4, 2.0, 5, N600);
  s.addText("K120,000", { x: M + 0.4, y: 2.4, w: 5.2, h: 1.0, isTextBox: true, fontFace: F, fontSize: 48, bold: true, color: INK, margin: 0 });
  T(s, "Includes the CRM for up to 50 users, USSD and SMS set-up, agent training at every branch, and data import. Excludes network fees, which MTN and Airtel bill you directly.", { x: M + 0.4, y: 3.5, w: 5.2, h: 1.6, fontSize: 13, color: N700, lineSpacingMultiple: 1.25, valign: "top" });
  label(s, "Then K9,500 per month", M + 0.4, 5.4, 5, STRONG);
  T(s, "Hosting in Lusaka, support 07:00 to 19:00, updates.", { x: M + 0.4, y: 5.7, w: 5.2, h: 0.4, fontSize: 13, color: N700 });
  const terms = [["Payment", "50% on signing, 50% at go-live"], ["Contract", "12 months, then monthly"], ["Data", "Yours. Full export any time, no fee"], ["Uptime", "99.5% monthly, credits if we miss it"], ["Support", "Engineer on the phone, not a ticket queue"]];
  terms.forEach((t, i) => {
    const y = 1.8 + i * 0.88;
    T(s, t[0], { x: 7.2, y, w: 1.8, h: 0.4, fontSize: 13, bold: true });
    T(s, t[1], { x: 9.0, y, w: 3.7, h: 0.6, fontSize: 13, color: N700, valign: "top" });
    s.addShape(pres.ShapeType.line, { x: 7.2, y: y + 0.7, w: 5.5, h: 0, line: { color: N200, width: 0.75 } });
  });
  footer(s);
  s.addNotes("Price. One number, large. Everything that is included in one paragraph, everything excluded in one sentence. Terms as label/value pairs.");
}
// ---------- 12. Contact / end (dark) ----------
{
  const s = pres.addSlide(); s.background = { color: INK };
  s.addImage({ data: PNG("ontech-boxed-primary-2400.png"), x: M, y: 0.8, w: 4.2, h: 4.2 * (235 / 566) });
  T(s, "Talk to an engineer, not a sales line.", { x: M, y: 3.2, w: 8, h: 0.9, fontSize: 30, bold: true, color: PAPER });
  const c = [["Dennis Zitha", "dennis@ontech.co.zm"], ["Phone", "+260 97 000 0000"], ["Dial", "*388#"], ["Web", "ontech.co.zm"]];
  c.forEach((r, i) => {
    const y = 4.4 + i * 0.5;
    T(s, r[0], { x: M, y, w: 1.6, h: 0.4, fontSize: 13, color: N400 });
    s.addText(r[1], { x: M + 1.7, y, w: 6, h: 0.4, isTextBox: true, fontFace: r[0] === "Dial" ? MONO : F, fontSize: 14, color: r[0] === "Dial" ? SIGNAL_DARK : PAPER, margin: 0 });
  });
  label(s, "Ontech Solutions Ltd  ·  Lusaka, Zambia", M, H - 0.9, 8, N400);
  s.addNotes("Contact. Replace the name, email and phone. The company line in the footer stays as the legal name.");
}

const out = path.join(ROOT, "templates", "deck", "ONTECH-deck-template.pptx");
fs.mkdirSync(path.dirname(out), { recursive: true });
pres.writeFile({ fileName: out }).then(() => console.log("wrote", out));
