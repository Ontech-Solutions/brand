"""ONTECH design tokens: colour, type, space, radius, motion. Emits tokens.json + tokens.css and a contrast report."""
import json, os

def lum(hexs):
    r, g, b = [int(hexs[i:i+2], 16) / 255 for i in (1, 3, 5)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

def contrast(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)

# ---- Colour -------------------------------------------------------------
# Neutrals are warm-tinted (a touch of red/yellow) so they sit with the amber accent.
neutral = {
    "ink":  "#111111",   # brand black, unchanged
    "900":  "#1F1D1A",
    "800":  "#33302B",
    "700":  "#55504A",
    "600":  "#6E6861",   # lowest text-safe grey on paper (4.5:1)
    "500":  "#8E8780",
    "400":  "#B3ACA4",
    "300":  "#D6D0C8",
    "200":  "#E9E5DF",
    "100":  "#F4F1EC",
    "paper": "#FFFFFF",
}
# Signal: one warm amber. "On" state, CTA, active, the *388# code. Never a background for body text.
signal = {
    "signal":        "#F5A524",  # on ink and on paper as a fill; text on it is ink
    "signal-strong": "#945600",  # text-safe on paper (5.9:1 against #FFFFFF)
    "signal-soft":   "#FFF1D6",  # tint for highlighted rows / callouts on paper
    "signal-dark":   "#FFB84D",  # the accent as used on ink backgrounds (dark mode)
}
semantic = {
    # light (on paper)                  dark (on ink)
    "success": {"text": "#1E7B3E", "fill": "#2FA35A", "soft": "#E3F4E8", "dark-text": "#6FD48F", "dark-soft": "#153A22"},
    "warning": {"text": "#9A5B00", "fill": "#CC7A00", "soft": "#FFF0D6", "dark-text": "#FFC266", "dark-soft": "#3E2A08"},
    "error":   {"text": "#B3261E", "fill": "#D93A31", "soft": "#FBE5E3", "dark-text": "#FF8A80", "dark-soft": "#4A1512"},
    "info":    {"text": "#1F5FA8", "fill": "#2F7BD1", "soft": "#E4EEFA", "dark-text": "#8CBDF2", "dark-soft": "#12294A"},
}
# Chart palette: signal first, then restrained hues that hold on both paper and ink.
chart = ["#F5A524", "#2F7BD1", "#2FA35A", "#8E8780", "#D93A31", "#7A5AC9", "#1F9FA8", "#C67A00"]

# ---- Type ----------------------------------------------------------------
type_scale = {
    "family": {"display": "Jost", "ui": "Jost", "mono": "JetBrains Mono", "fallback": "system-ui, -apple-system, Segoe UI, Roboto, sans-serif", "mono-fallback": "ui-monospace, SFMono-Regular, Menlo, monospace"},
    "weight": {"regular": 400, "medium": 500, "semibold": 600},
    # 8 sizes. rem at 16px base. Display sizes use tighter tracking; caps label uses wide tracking (as in the logo tagline).
    "size": {
        "display": {"px": 56, "line": 1.05, "tracking": "-0.02em", "weight": 600},
        "h1":      {"px": 40, "line": 1.10, "tracking": "-0.015em", "weight": 600},
        "h2":      {"px": 28, "line": 1.20, "tracking": "-0.01em", "weight": 600},
        "h3":      {"px": 20, "line": 1.30, "tracking": "0", "weight": 500},
        "body":    {"px": 16, "line": 1.55, "tracking": "0", "weight": 400},
        "small":   {"px": 14, "line": 1.50, "tracking": "0", "weight": 400},
        "label":   {"px": 12, "line": 1.30, "tracking": "0.14em", "weight": 500, "transform": "uppercase"},
        "code":    {"px": 14, "line": 1.50, "tracking": "0", "weight": 500, "family": "mono"},
    },
}
space = {"1": 4, "2": 8, "3": 12, "4": 16, "5": 24, "6": 32, "7": 48, "8": 64, "9": 96}
radius = {"none": 0, "sm": 4, "md": 8, "lg": 12, "pill": 999}   # logo box is always radius none
motion = {"instant": 120, "quick": 200, "standard": 300, "deliberate": 500,
          "ease-swift": "cubic-bezier(0.32,0,0.15,1)", "ease-settle": "cubic-bezier(0.22,1,0.36,1)"}

tokens = {
    "$schema": "ontech-tokens/1",
    "version": "1.0.0",
    "color": {"neutral": neutral, "signal": signal, "semantic": semantic, "chart": chart,
              "role": {
                  "light": {"bg": "{neutral.paper}", "bg-subtle": "{neutral.100}", "fg": "{neutral.ink}", "fg-muted": "{neutral.600}", "border": "{neutral.300}", "accent": "{signal.signal}", "accent-text": "{signal.signal-strong}", "accent-soft": "{signal.signal-soft}"},
                  "dark":  {"bg": "{neutral.ink}", "bg-subtle": "{neutral.900}", "fg": "{neutral.paper}", "fg-muted": "{neutral.400}", "border": "{neutral.700}", "accent": "{signal.signal-dark}", "accent-text": "{signal.signal-dark}", "accent-soft": "#3A2A0E"},
              }},
    "type": type_scale, "space": space, "radius": radius, "motion": motion,
}

# ---- Contrast report -------------------------------------------------------
report = []
def chk(name, fg, bg, need):
    c = contrast(fg, bg); report.append((name, fg, bg, round(c, 2), need, c >= need))
chk("ink on paper", neutral["ink"], neutral["paper"], 7)
chk("neutral-600 (muted text) on paper", neutral["600"], neutral["paper"], 4.5)
chk("neutral-400 (muted text) on ink", neutral["400"], neutral["ink"], 4.5)
chk("ink on signal (button label)", neutral["ink"], signal["signal"], 4.5)
chk("signal-strong (accent text) on paper", signal["signal-strong"], neutral["paper"], 4.5)
chk("signal-dark (accent text) on ink", signal["signal-dark"], neutral["ink"], 4.5)
chk("signal on ink (non-text, UI)", signal["signal"], neutral["ink"], 3)
chk("signal on paper (fill only; always carries an ink label or ink border — see rule 3)", signal["signal"], neutral["paper"], 1)
chk("ink on signal-soft", neutral["ink"], signal["signal-soft"], 7)
for k, v in semantic.items():
    chk(f"{k} text on paper", v["text"], neutral["paper"], 4.5)
    chk(f"{k} text on {k} soft", v["text"], v["soft"], 4.5)
    chk(f"{k} fill on paper (UI)", v["fill"], neutral["paper"], 3)
    chk(f"{k} dark-text on ink", v["dark-text"], neutral["ink"], 4.5)
    chk(f"{k} dark-text on dark-soft", v["dark-text"], v["dark-soft"], 4.5)
chk("border-300 on paper (UI)", neutral["300"], neutral["paper"], 1.3)

ROOT = os.path.join(os.path.dirname(__file__), "out", "ontech-brand", "tokens")
os.makedirs(ROOT, exist_ok=True)
json.dump(tokens, open(os.path.join(ROOT, "tokens.json"), "w"), indent=2)

# ---- CSS ---------------------------------------------------------------
css = [":root {", "  /* ONTECH design tokens v1.0.0 — generated, do not hand-edit */"]
for k, v in neutral.items(): css.append(f"  --on-{k if k in ('ink','paper') else 'neutral-'+k}: {v};")
for k, v in signal.items(): css.append(f"  --on-{k}: {v};")
for k, v in semantic.items():
    for kk, vv in v.items(): css.append(f"  --on-{k}-{kk}: {vv};")
for i, c in enumerate(chart, 1): css.append(f"  --on-chart-{i}: {c};")
css += ["", "  --on-font-display: 'Jost', " + type_scale["family"]["fallback"] + ";",
        "  --on-font-ui: 'Jost', " + type_scale["family"]["fallback"] + ";",
        "  --on-font-mono: 'JetBrains Mono', " + type_scale["family"]["mono-fallback"] + ";"]
for k, v in type_scale["size"].items():
    css.append(f"  --on-text-{k}: {v['px']/16:g}rem; --on-leading-{k}: {v['line']}; --on-tracking-{k}: {v['tracking']}; --on-weight-{k}: {v['weight']};")
for k, v in space.items(): css.append(f"  --on-space-{k}: {v}px;")
for k, v in radius.items(): css.append(f"  --on-radius-{k}: {v}px;")
for k, v in motion.items(): css.append(f"  --on-motion-{k}: {v}{'ms' if isinstance(v,int) else ''};")
css += ["", "  /* roles — light */",
        "  --on-bg: var(--on-paper); --on-bg-subtle: var(--on-neutral-100); --on-fg: var(--on-ink); --on-fg-muted: var(--on-neutral-600);",
        "  --on-border: var(--on-neutral-300); --on-accent: var(--on-signal); --on-accent-text: var(--on-signal-strong); --on-accent-soft: var(--on-signal-soft);",
        "  --on-success-text-role: var(--on-success-text); --on-success-soft-role: var(--on-success-soft);",
        "  --on-warning-text-role: var(--on-warning-text); --on-warning-soft-role: var(--on-warning-soft);",
        "  --on-error-text-role: var(--on-error-text); --on-error-soft-role: var(--on-error-soft);",
        "  --on-info-text-role: var(--on-info-text); --on-info-soft-role: var(--on-info-soft);",
        "  color-scheme: light dark;", "}", "",
        "[data-theme='dark'] {", "  --on-bg: var(--on-ink); --on-bg-subtle: var(--on-neutral-900); --on-fg: var(--on-paper); --on-fg-muted: var(--on-neutral-400);",
        "  --on-border: var(--on-neutral-700); --on-accent: var(--on-signal-dark); --on-accent-text: var(--on-signal-dark); --on-accent-soft: #3A2A0E;",
        "  --on-success-text-role: var(--on-success-dark-text); --on-success-soft-role: var(--on-success-dark-soft);",
        "  --on-warning-text-role: var(--on-warning-dark-text); --on-warning-soft-role: var(--on-warning-dark-soft);",
        "  --on-error-text-role: var(--on-error-dark-text); --on-error-soft-role: var(--on-error-dark-soft);",
        "  --on-info-text-role: var(--on-info-dark-text); --on-info-soft-role: var(--on-info-dark-soft);", "}", "",
        "@media (prefers-color-scheme: dark) { :root:not([data-theme='light']) {",
        "  --on-bg: var(--on-ink); --on-bg-subtle: var(--on-neutral-900); --on-fg: var(--on-paper); --on-fg-muted: var(--on-neutral-400);",
        "  --on-border: var(--on-neutral-700); --on-accent: var(--on-signal-dark); --on-accent-text: var(--on-signal-dark); --on-accent-soft: #3A2A0E;",
        "  --on-success-text-role: var(--on-success-dark-text); --on-success-soft-role: var(--on-success-dark-soft);",
        "  --on-warning-text-role: var(--on-warning-dark-text); --on-warning-soft-role: var(--on-warning-dark-soft);",
        "  --on-error-text-role: var(--on-error-dark-text); --on-error-soft-role: var(--on-error-dark-soft);",
        "  --on-info-text-role: var(--on-info-dark-text); --on-info-soft-role: var(--on-info-dark-soft);", "} }"]
open(os.path.join(ROOT, "tokens.css"), "w").write("\n".join(css) + "\n")

lines = ["# Contrast report (WCAG 2.x)", "", "Rules: (1) body text is ink on paper or paper on ink, never on the accent. (2) Accent text on paper uses signal-strong, never signal. (3) The raw signal amber fails 3:1 on white, so on paper it appears only as a fill that carries an ink label, an ink border, or sits on ink (a black button bar, the black logo frame). (4) Dark mode uses the -dark pairs; never the light values inverted.", "", "| Pair | Foreground | Background | Ratio | Needs | Pass |", "| --- | --- | --- | --- | --- | --- |"]
for n, fg, bg, c, need, ok in report:
    lines.append(f"| {n} | {fg} | {bg} | {c}:1 | {need}:1 | {'yes' if ok else 'NO'} |")
open(os.path.join(ROOT, "contrast-report.md"), "w").write("\n".join(lines) + "\n")
fails = [r for r in report if not r[5]]
print("\n".join(lines))
print("FAILS:", [(r[0], r[3]) for r in fails])
